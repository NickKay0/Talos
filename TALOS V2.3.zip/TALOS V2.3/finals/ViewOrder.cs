﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finals
{
    public partial class ViewOrder : Form
    {
        public ViewOrder()
        {
            InitializeComponent();

            TypeBox.SelectedIndex = 0;
        }

        private void TypeBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "";
            SqlConnection con;
            SqlCommand command;
            SqlDataAdapter da;
            con = new SqlConnection(Functions.GetConnectionString());
            con.Open();

            DataTable dt;
            try
            {
                switch (TypeBox.SelectedIndex)
                {
                    case 0:
                        //sql = "select SalesOrderID as 'Order ID',RevisionNumber as 'Revision No.',OrderDate as 'Order Date', DueDate as 'Due Date',ShipDate as 'Ship Date',status,OnlineOrderFlag as 'Ordered Online',SalesOrderNumber as 'Sales Order No.',CustomerID as 'Customer ID',SalesPersonID as 'Salesperson ID',concat(AddressLine1,', ',city,' - ',PostalCode) as 'Address',concat(SalesTerritory.name ,',',CountryRegionCode) as 'Territory',ShipMethod.name as 'Shipping Method',CardNumber as 'Card No.',SubTotal,TaxAmt as 'Tax Amt.',Freight,TotalDue from sales.SalesOrderHeader join sales.SalesTerritory on SalesTerritory.TerritoryID = SalesOrderHeader.TerritoryID join person.Address on AddressID = SalesOrderHeader.BillToAddressID join Purchasing.ShipMethod on ShipMethod.ShipMethodID= SalesOrderHeader.ShipMethodID join sales.CreditCard on CreditCard.CreditCardID = SalesOrderHeader.CreditCardID order by salesorderheader.modifieddate desc";
                        //sql = "select * from vSalesOrderHeader order by [Order Date] desc";
                        sql = "select top(1)* from vSalesOrderHeader order by [Order Date] desc";
                        command = new SqlCommand(sql, con);
                        da = new SqlDataAdapter(command);
                        dt = new DataTable();
                        da.Fill(dt);
                        OrderGridView.DataSource = dt;

                        //fix visuals of data grid view
                        OrderGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                        OrderGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                        break;
                    case 1:
                        //sql = "select WorkOrderID as 'ID', workorder.ProductID,product.name as 'Name',OrderQty,StockedQty,ScrappedQty,ScrapReason.Name as 'Scrap Reason',StartDate,EndDate,DueDate from production.workorder join production.product on product.ProductID = WorkOrder.ProductID left join production.ScrapReason on ScrapReason.ScrapReasonID = WorkOrder.ScrapReasonID order by workorder.ModifiedDate desc";
                        //sql = "select * from vWorkOrderHeader order by startdate desc";
                        sql = "select top(10)* from vWorkOrderHeader order by startdate desc";
                        command = new SqlCommand(sql, con);
                        da = new SqlDataAdapter(command);
                        dt = new DataTable();
                        da.Fill(dt);
                        OrderGridView.DataSource = dt;

                        //fix visuals of data grid view
                        OrderGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                        OrderGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                        break;
                    case 2:
                        //sql = "select purchaseorderid as 'ID',revisionnumber,status,employeeID, VendorID,Vendor.Name as 'Vendor',ShipMethod.Name as 'Ship Method',OrderDate,ShipDate,SubTotal,TaxAmt,Freight,TotalDue from Purchasing.PurchaseOrderHeader join Purchasing.Vendor on vendor.BusinessEntityID =PurchaseOrderHeader.VendorID join purchasing.ShipMethod on ShipMethod.ShipMethodID = PurchaseOrderHeader.ShipMethodID order by PurchaseOrderheader.modifieddate desc";
                        //sql = "select * from vPurchaseOrderHeader order by orderdate desc";
                        sql = "select top(10)* from vPurchaseOrderHeader order by orderdate desc";
                        command = new SqlCommand(sql, con);
                        da = new SqlDataAdapter(command);
                        dt = new DataTable();
                        da.Fill(dt);
                        OrderGridView.DataSource = dt;

                        //fix visuals of data grid view
                        OrderGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                        OrderGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                        break;
                }
                con.Close();
            }
            catch (SqlException ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void OrderGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            ViewOrderBtn_Click(null, null);
        }

        public void SearchCode()
        {
            BindingSource bs_sp = new BindingSource();

            bs_sp.DataSource = OrderGridView.DataSource;
            bs_sp.Filter = "Convert(ID, 'System.String') like '" + SearchBox.Text + "%'";
            OrderGridView.DataSource = bs_sp;
        }


        private void ViewOrderBtn_Click(object sender, EventArgs e)
        {
            try
            {
                switch (TypeBox.SelectedIndex)
                {
                    case 0:
                        ViewOrderDetail vods = new ViewOrderDetail(int.Parse(OrderGridView.SelectedRows[0].Cells[0].Value.ToString()),0);
                        vods.Show();
                        break;
                    case 1:
                        ViewOrderDetail vodw = new ViewOrderDetail(int.Parse(OrderGridView.SelectedRows[0].Cells[0].Value.ToString()),1);
                        vodw.Show();
                        break;
                    case 2:
                        ViewOrderDetail vodp = new ViewOrderDetail(int.Parse(OrderGridView.SelectedRows[0].Cells[0].Value.ToString()), 2);
                        vodp.Show();
                        break;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            SearchCode();
        }
    }
}
