﻿    using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finals
{
    public partial class ViewOrderDetail : Form
    {
        public ViewOrderDetail(int orderID, int type)
        {
            InitializeComponent();

            string sql = "";
            SqlConnection con;
            SqlCommand command;
            SqlDataAdapter da;
            con = new SqlConnection(Functions.GetConnectionString());
            con.Open();

            DataTable dt;
            try
            {
                switch (type)
                {
                    case 0:
                        sql = "select SalesOrderID as 'ID',ROW_NUMBER() over (order by salesorderid) as 'Row',CarrierTrackingNumber,OrderQty as 'Qty',salesorderdetail.ProductID as 'Prod. Code',product.Name as 'Name',SpecialOffer.Description,UnitPrice,UnitPriceDiscount as 'Discount',LineTotal from sales.SalesOrderDetail join production.product on product.productid = salesorderdetail.ProductID join sales.SpecialOffer on SpecialOffer.SpecialOfferID = salesorderdetail.SpecialOfferID where salesorderid = " + orderID;
                        command = new SqlCommand(sql, con);
                        da = new SqlDataAdapter(command);
                        dt = new DataTable();
                        da.Fill(dt);
                        OrderGridView.DataSource = dt;

                        //fix visuals of data grid view
                        OrderGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                        OrderGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        OrderGridView.Columns[0].Width = 60;
                        OrderGridView.Columns[1].Width = 50;
                        OrderGridView.Columns[2].Width = 115;
                        OrderGridView.Columns[3].Width = 50;
                        OrderGridView.Columns[4].Width = 50;
                        OrderGridView.Columns[5].Width = 200;
                        OrderGridView.Columns[6].Width = 160;

                        break;
                    case 1:
                        sql = "select PurchaseOrderID as 'ID', ROW_NUMBER() over (order by purchaseorderid) as 'Row',DueDate as 'Due Date',purchaseorderdetail.ProductID as 'Prod. Code',name as 'Name',OrderQty as 'Ordered Qty',ReceivedQty as 'Received',RejectedQty as 'Rejected',StockedQty as 'Stocked',LineTotal from Purchasing.PurchaseOrderDetail join production.product on Product.ProductID = PurchaseOrderDetail.ProductID where PurchaseOrderID = " + orderID;
                        command = new SqlCommand(sql, con);
                        da = new SqlDataAdapter(command);
                        dt = new DataTable();
                        da.Fill(dt);
                        OrderGridView.DataSource = dt;

                        //fix visuals of data grid view
                        OrderGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                        OrderGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                        OrderGridView.Columns[0].Width = 60;
                        OrderGridView.Columns[1].Width = 60;
                        OrderGridView.Columns[2].Width = 150;
                        OrderGridView.Columns[3].Width = 60;
                        OrderGridView.Columns[4].Width = 200;
                        OrderGridView.Columns[5].Width = 70;
                        OrderGridView.Columns[6].Width = 70;
                        OrderGridView.Columns[7].Width = 70;

                        break;
                    case 2:
                        sql = "select PurchaseOrderID as 'ID', ROW_NUMBER() over (order by purchaseorderid) as 'Row',DueDate as 'Due Date',purchaseorderdetail.ProductID as 'Prod. Code',name as 'Name',OrderQty as 'Ordered Qty',ReceivedQty as 'Received',RejectedQty as 'Rejected',StockedQty as 'Stocked',LineTotal from Purchasing.PurchaseOrderDetail join production.product on Product.ProductID = PurchaseOrderDetail.ProductID where PurchaseOrderID = " + orderID;
                        command = new SqlCommand(sql, con);
                        da = new SqlDataAdapter(command);
                        dt = new DataTable();
                        da.Fill(dt);
                        OrderGridView.DataSource = dt;

                        //fix visuals of data grid view
                        OrderGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                        OrderGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                        OrderGridView.Columns[0].Width = 60;
                        OrderGridView.Columns[1].Width = 60;
                        OrderGridView.Columns[2].Width = 150;
                        OrderGridView.Columns[3].Width = 60;
                        OrderGridView.Columns[4].Width = 200;
                        OrderGridView.Columns[5].Width = 70;
                        OrderGridView.Columns[6].Width = 70;
                        OrderGridView.Columns[7].Width = 70;

                        break;
                }
                con.Close();
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
