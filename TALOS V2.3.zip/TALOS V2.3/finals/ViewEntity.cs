﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finals
{
    public partial class ViewEntity : Form
    {
        public ViewEntity()
        {
            InitializeComponent();

            TypeBox.SelectedIndex = 1;
        }

        private void TypeBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string sql = "";
                SqlConnection con;
                SqlCommand command;
                SqlDataAdapter da;
                con = new SqlConnection(Functions.GetConnectionString());
                con.Open();

                DataTable dt;
                switch (TypeBox.SelectedIndex)
                {
                    case 0:
                        sql = "select person.BusinessEntityID as 'ID', concat(FirstName,' ',LastName) as 'Name',AccountNumber as 'Account Number',PhoneNumber as 'Phone Number' from person.Person left join sales.Customer on customer.CustomerID = Person.BusinessEntityID join person.PersonPhone on PersonPhone.BusinessEntityID = person.BusinessEntityID where PersonType = 'sc'";
                        command = new SqlCommand(sql, con);
                        da = new SqlDataAdapter(command);
                        dt = new DataTable();
                        da.Fill(dt);
                        EntityGridView.DataSource = dt;

                        //fix visuals of data grid view
                        EntityGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                        EntityGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                        EntityGridView.Columns[0].Width = 60;
                        EntityGridView.Columns[1].Width = 150;
                        EntityGridView.Columns[2].Width = 115;
                        EntityGridView.Columns[3].Width = 145;

                        break;
                    case 1:
                        sql = "select top(20)* from vPersonPerson";

                        //sql = "select person.BusinessEntityID as 'ID', concat(FirstName,' ',LastName) as 'Name',AccountNumber as 'Account Number',addressline1 as 'Address',PostalCode as 'Postal Code',city as 'City', EmailAddress as 'Email', PhoneNumber as 'Phone' from person.person join sales.customer on customer.PersonID = person.BusinessEntityID join person.BusinessEntityAddress on BusinessEntityAddress.BusinessEntityID = person.BusinessEntityID join person.Address on address.AddressID = BusinessEntityAddress.AddressID join person.EmailAddress on EmailAddress.BusinessEntityID = person.BusinessEntityID left join person.PersonPhone on PersonPhone.BusinessEntityID = person.BusinessEntityID where PersonType = 'in' order by name asc";
                        //for optimization
                        //sql = "select top(250) person.BusinessEntityID as 'ID', concat(FirstName,' ',LastName) as 'Name',AccountNumber as 'Account Number',addressline1 as 'Address',PostalCode as 'Postal Code',city as 'City', EmailAddress as 'Email', PhoneNumber as 'Phone' from person.person join sales.customer on customer.PersonID = person.BusinessEntityID join person.BusinessEntityAddress on BusinessEntityAddress.BusinessEntityID = person.BusinessEntityID join person.Address on address.AddressID = BusinessEntityAddress.AddressID join person.EmailAddress on EmailAddress.BusinessEntityID = person.BusinessEntityID left join person.PersonPhone on PersonPhone.BusinessEntityID = person.BusinessEntityID where PersonType = 'in' order by name asc";
                        command = new SqlCommand(sql, con);
                        da = new SqlDataAdapter(command);
                        dt = new DataTable();
                        da.Fill(dt);
                        EntityGridView.DataSource = dt;

                        //fix visuals of data grid view
                        EntityGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                        EntityGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                        EntityGridView.Columns[0].Width = 60;
                        EntityGridView.Columns[1].Width = 150;
                        EntityGridView.Columns[2].Width = 115;
                        EntityGridView.Columns[3].Width = 200;
                        EntityGridView.Columns[4].Width = 80;
                        EntityGridView.Columns[5].Width = 80;
                        EntityGridView.Columns[6].Width = 250;
                        EntityGridView.Columns[7].Width = 150;

                        break;
                    case 2:
                        sql = "select person.BusinessEntityID as 'ID', concat(FirstName,' ',LastName) as 'Name',PhoneNumber as 'Phone',AddressLine1 as 'Address',PostalCode as 'Postal Code',city as 'City',EmailAddress as 'Email',SalesQuota as 'Yearly Quota',SalesYTD as 'Sales',SalesLastYear as 'Sales Last Year',Bonus as 'Bonus',CommissionPct as 'Commision %' from person.Person join sales.SalesPerson on SalesPerson.BusinessEntityID = person.BusinessEntityID join person.PersonPhone on PersonPhone.BusinessEntityID = person.BusinessEntityID join person.BusinessEntityAddress on BusinessEntityAddress.BusinessEntityID = person.BusinessEntityID join Person.Address on address.AddressID = BusinessEntityAddress.AddressID join person.EmailAddress on EmailAddress.BusinessEntityID = person.BusinessEntityID where PersonType = 'sp'";
                        command = new SqlCommand(sql, con);
                        da = new SqlDataAdapter(command);
                        dt = new DataTable();
                        da.Fill(dt);
                        EntityGridView.DataSource = dt;

                        //fix visuals of data grid view
                        EntityGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                        EntityGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                        break;
                    case 3:
                        sql = "select person.BusinessEntityID as 'ID', concat(FirstName,' ',LastName) as 'Name',NationalIDNumber as 'National ID',LoginID as 'Login ID',OrganizationLevel as 'Organization Level',JobTitle as 'Job Title',PhoneNumber as 'Phone Number',AddressLine1 as 'Address', PostalCode as 'Postal Code',city as 'City',EmailAddress as 'Email',BirthDate as 'D.O.B.', MaritalStatus as 'Marrital',HireDate as 'Hired Date', VacationHours as 'Vacation Hours',SickLeaveHours as 'Sick Leave Hours',SalariedFlag as 'Salaried' from person.Person join HumanResources.Employee on Employee.BusinessEntityID = person.BusinessEntityID join person.PersonPhone on PersonPhone.BusinessEntityID = Person.BusinessEntityID join person.BusinessEntityAddress on BusinessEntityAddress.BusinessEntityID = person.BusinessEntityID join person.Address on address.AddressID = person.BusinessEntityID join person.EmailAddress on EmailAddress.BusinessEntityID = person.BusinessEntityID where PersonType = 'em'";
                        command = new SqlCommand(sql, con);
                        da = new SqlDataAdapter(command);
                        dt = new DataTable();
                        da.Fill(dt);
                        EntityGridView.DataSource = dt;

                        //fix visuals of data grid view
                        EntityGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                        EntityGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                        break;
                    case 4:
                        sql = "select person.BusinessEntityID as 'ID',concat(FirstName,' ',LastName) as 'Name',PhoneNumber as 'Phone',EmailAddress as 'Email' from person.Person join person.PersonPhone on PersonPhone.BusinessEntityID = person.BusinessEntityID join person.EmailAddress on EmailAddress.BusinessEntityID = Person.BusinessEntityID where PersonType = 'vc'";
                        command = new SqlCommand(sql, con);
                        da = new SqlDataAdapter(command);
                        dt = new DataTable();
                        da.Fill(dt);
                        EntityGridView.DataSource = dt;

                        //fix visuals of data grid view
                        EntityGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                        EntityGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                        break;
                    case 5:
                        sql = "select person.BusinessEntityID as 'ID', concat(FirstName,' ',LastName) as 'Name', PhoneNumber as 'Phone',EmailAddress as 'Email' from person.person join person.PersonPhone on PersonPhone.BusinessEntityID = Person.BusinessEntityID join person.EmailAddress on EmailAddress.BusinessEntityID = person.BusinessEntityID where PersonType = 'gc'";
                        command = new SqlCommand(sql, con);
                        da = new SqlDataAdapter(command);
                        dt = new DataTable();
                        da.Fill(dt);
                        EntityGridView.DataSource = dt;

                        //fix visuals of data grid view
                        EntityGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                        EntityGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                        break;
                }
                con.Close();
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void SearchName()
        {
            (EntityGridView.DataSource as DataTable).DefaultView.RowFilter = string.Format("Name LIKE '%{0}%'", SearchBox.Text);
        }

        public void SearchCode()
        {
            BindingSource bs_sp = new BindingSource();

            bs_sp.DataSource = EntityGridView.DataSource;
            bs_sp.Filter = "Convert(ID, 'System.String') like '" + SearchBoxCode.Text + "%'";
            EntityGridView.DataSource = bs_sp;
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            SearchBoxCode.Text = "";
            SearchName();
        }

        private void SearchBoxCode_KeyDown(object sender, KeyEventArgs e)
        {
            SearchBox.Text = "";
            SearchCode();
        }
    }
}
