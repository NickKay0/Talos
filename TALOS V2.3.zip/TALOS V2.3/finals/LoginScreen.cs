﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace finals
{
    public partial class LoginScreen : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,
            int nTopRect,
            int nRightRect,
            int nBottomRect,
            int nWidthEllipse,
            int nHeightEllipse
        );

        public LoginScreen()
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 22, 22));

            UsernameBox.Select();
            UsernameBox.Focus();
            PasswordBox.UseSystemPasswordChar = true;
        }



        void Login()
        {
            string sql = $"select password from login where username = '{UsernameBox.Text}'";
            string connectionString = Functions.GetConnectionString();
            SqlConnection con;
            SqlCommand command;
            SqlDataReader dataReader;

            con = new SqlConnection(connectionString);
            con.Open();
            command = new SqlCommand(sql, con);
            dataReader = command.ExecuteReader();
            if (dataReader.Read())
            {
                string passwordGot = dataReader.GetString(0);
                if (passwordGot.Equals(PasswordBox.Text))
                {
                    Home h = new Home(UsernameBox.Text);
                    h.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Incorrect Username/Password", "Warning");
                    PasswordBox.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Incorrect Username/Password", "Warning");
            }
            con.Close();
            command.Dispose();
            dataReader.Close();
        }


        private void usernameBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == (char)Keys.Enter)
            {
                PasswordBox.Focus();
            }
        }

        private void passwordBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == (char)Keys.Enter)
            {
                Login();
            }
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            PasswordBox.UseSystemPasswordChar = false;
        }

        private void button2_MouseUp(object sender, MouseEventArgs e)
        {
            PasswordBox.UseSystemPasswordChar = true;
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MinimizeBtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            Login();
        }

        //drag around window
        private bool dragging = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            dragCursorPoint = Cursor.Position;
            dragFormPoint = this.Location;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(dif));
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }
    }
}
