﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finals
{
    public partial class ProvinceCode : Form
    {
        TextBox ProvinceBox;
        public ProvinceCode(TextBox tb)
        {
            InitializeComponent();

            string sql = "select StateProvinceID as 'ID', name as 'Name', StateProvinceCode as 'Province Code', CountryRegionCode as 'Country Code' from person.StateProvince order by Name asc";
            string connectionString = Functions.GetConnectionString();
            SqlConnection con;
            SqlCommand command;
            SqlDataAdapter da;

            con = new SqlConnection(connectionString);
            con.Open();
            command = new SqlCommand(sql, con);
            da = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);
            ProvinceGridView.DataSource = dt;

            ProvinceGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
            ProvinceGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;


            ProvinceGridView.Columns[0].Width = 60;
            ProvinceGridView.Columns[1].Width = 150;
            ProvinceGridView.Columns[2].Width = 100;

            ProvinceBox = tb;
        }

        public void SearchName()
        {
            (ProvinceGridView.DataSource as DataTable).DefaultView.RowFilter = string.Format("Name LIKE '%{0}%'", SearchBox.Text);
        }

        public void SearchCode()
        {
            BindingSource bs_sp = new BindingSource();

            bs_sp.DataSource = ProvinceGridView.DataSource;
            bs_sp.Filter = "Convert(ID, 'System.String') like '" + SearchBoxCode.Text + "%'";
            ProvinceGridView.DataSource = bs_sp;
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            SearchName();
            SearchBoxCode.Text = "";
        }

        private void SearchBoxCode_KeyDown(object sender, KeyEventArgs e)
        {
            SearchCode();
            SearchBox.Text = "";
        }

        private void ProvinceGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                ProvinceBox.Text = ProvinceGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                this.Dispose();
            }
            catch
            {

            }
        }
    }
}
