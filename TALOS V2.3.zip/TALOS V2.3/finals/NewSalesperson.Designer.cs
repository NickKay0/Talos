﻿namespace finals
{
    partial class NewSalesperson
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewSalesperson));
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.EmployeeIDBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.EmployeeIDHelpBtn = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.TerritoryBox = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SalesQuotaBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.BonusBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.CreateBtn = new System.Windows.Forms.Button();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel14.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(381, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(288, 32);
            this.label1.TabIndex = 122;
            this.label1.Text = "Create New Salesperson";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel2.Controls.Add(this.EmployeeIDBox);
            this.panel2.Location = new System.Drawing.Point(57, 131);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(142, 24);
            this.panel2.TabIndex = 124;
            // 
            // EmployeeIDBox
            // 
            this.EmployeeIDBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.EmployeeIDBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.EmployeeIDBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeIDBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.EmployeeIDBox.Location = new System.Drawing.Point(0, 0);
            this.EmployeeIDBox.Name = "EmployeeIDBox";
            this.EmployeeIDBox.Size = new System.Drawing.Size(140, 22);
            this.EmployeeIDBox.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(52, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 25);
            this.label3.TabIndex = 123;
            this.label3.Text = "Employee ID:";
            // 
            // EmployeeIDHelpBtn
            // 
            this.EmployeeIDHelpBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("EmployeeIDHelpBtn.BackgroundImage")));
            this.EmployeeIDHelpBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.EmployeeIDHelpBtn.FlatAppearance.BorderSize = 0;
            this.EmployeeIDHelpBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(82)))));
            this.EmployeeIDHelpBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EmployeeIDHelpBtn.Location = new System.Drawing.Point(205, 131);
            this.EmployeeIDHelpBtn.Name = "EmployeeIDHelpBtn";
            this.EmployeeIDHelpBtn.Size = new System.Drawing.Size(23, 25);
            this.EmployeeIDHelpBtn.TabIndex = 125;
            this.EmployeeIDHelpBtn.UseVisualStyleBackColor = true;
            this.EmployeeIDHelpBtn.Click += new System.EventHandler(this.EmployeeIDHelpBtn_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(286, 105);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 25);
            this.label15.TabIndex = 127;
            this.label15.Text = "Territory:";
            // 
            // TerritoryBox
            // 
            this.TerritoryBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.TerritoryBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TerritoryBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TerritoryBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.TerritoryBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.TerritoryBox.FormattingEnabled = true;
            this.TerritoryBox.Items.AddRange(new object[] {
            "Northwest US, North America",
            "Northeast US, North America",
            "Central US, North America",
            "Southwest US, North America",
            "Southeast US, North America",
            "Canada CA, North America",
            "France FR, Europe",
            "Germany DE, Europe",
            "Australia AU, Pacific",
            "United Kingdom GB, Europe"});
            this.TerritoryBox.Location = new System.Drawing.Point(291, 133);
            this.TerritoryBox.Name = "TerritoryBox";
            this.TerritoryBox.Size = new System.Drawing.Size(226, 25);
            this.TerritoryBox.TabIndex = 126;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel1.Controls.Add(this.SalesQuotaBox);
            this.panel1.Location = new System.Drawing.Point(594, 131);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(142, 24);
            this.panel1.TabIndex = 129;
            // 
            // SalesQuotaBox
            // 
            this.SalesQuotaBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.SalesQuotaBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SalesQuotaBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalesQuotaBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.SalesQuotaBox.Location = new System.Drawing.Point(0, 0);
            this.SalesQuotaBox.Name = "SalesQuotaBox";
            this.SalesQuotaBox.Size = new System.Drawing.Size(140, 22);
            this.SalesQuotaBox.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(589, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 25);
            this.label2.TabIndex = 128;
            this.label2.Text = "Sales Quota:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel3.Controls.Add(this.BonusBox);
            this.panel3.Location = new System.Drawing.Point(818, 131);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(142, 24);
            this.panel3.TabIndex = 131;
            // 
            // BonusBox
            // 
            this.BonusBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.BonusBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BonusBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BonusBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.BonusBox.Location = new System.Drawing.Point(0, 0);
            this.BonusBox.Name = "BonusBox";
            this.BonusBox.Size = new System.Drawing.Size(140, 22);
            this.BonusBox.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(813, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 25);
            this.label4.TabIndex = 130;
            this.label4.Text = "Bonus:";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel14.Controls.Add(this.CreateBtn);
            this.panel14.Location = new System.Drawing.Point(414, 278);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(202, 50);
            this.panel14.TabIndex = 132;
            // 
            // CreateBtn
            // 
            this.CreateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.CreateBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CreateBtn.FlatAppearance.BorderSize = 0;
            this.CreateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CreateBtn.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.CreateBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.CreateBtn.Location = new System.Drawing.Point(0, 0);
            this.CreateBtn.Name = "CreateBtn";
            this.CreateBtn.Size = new System.Drawing.Size(198, 46);
            this.CreateBtn.TabIndex = 51;
            this.CreateBtn.Text = "Create Salesperson";
            this.CreateBtn.UseVisualStyleBackColor = false;
            this.CreateBtn.Click += new System.EventHandler(this.CreateBtn_Click);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(44)))), ((int)(((byte)(63)))));
            this.panel15.Location = new System.Drawing.Point(12, 342);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(982, 2);
            this.panel15.TabIndex = 133;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkGray;
            this.label5.Location = new System.Drawing.Point(19, 363);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(617, 17);
            this.label5.TabIndex = 134;
            this.label5.Text = "*To create a new salesperson, first create an employee and then select them from " +
    "the employee id";
            // 
            // NewSalesperson
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1006, 392);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.TerritoryBox);
            this.Controls.Add(this.EmployeeIDHelpBtn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "NewSalesperson";
            this.Text = "New Salesperson";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox EmployeeIDBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button EmployeeIDHelpBtn;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox TerritoryBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox SalesQuotaBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox BonusBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button CreateBtn;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label5;
    }
}