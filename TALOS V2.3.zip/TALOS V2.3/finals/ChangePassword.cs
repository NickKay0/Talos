﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finals
{
    public partial class ChangePassword : Form
    {
        string username;
        public ChangePassword(string username)
        {
            InitializeComponent();
            CurrentPasswordBox.UseSystemPasswordChar = true;
            NewPasswordBox.UseSystemPasswordChar = true;
            this.username = username;
            UsernameBox.Text = username;
            CurrentPasswordBox.Focus();
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            CurrentPasswordBox.UseSystemPasswordChar = false;
        }

        private void button1_MouseUp(object sender, MouseEventArgs e)
        {
            CurrentPasswordBox.UseSystemPasswordChar = true;
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            NewPasswordBox.UseSystemPasswordChar = false;
        }

        private void button2_MouseUp(object sender, MouseEventArgs e)
        {
            NewPasswordBox.UseSystemPasswordChar = true;
        }

        void UpdatePass()
        {
            SqlConnection con = new SqlConnection(Functions.GetConnectionString());
            SqlCommand command;
            SqlDataReader reader;
            string sql = "select password from login where username = '"+username+"'";
            con.Open();
            
            command = new SqlCommand (sql, con);
            reader = command.ExecuteReader();
            if (reader.Read())
            {
                if(reader.GetString(0) == CurrentPasswordBox.Text)
                {
                    sql = $"update login set password = '{NewPasswordBox.Text}' where username = '{username}'";
                    command = new SqlCommand (sql, con);
                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();
                    MessageBox.Show("Password Updated Succesfully","Success");
                }
                else
                {
                    MessageBox.Show("Incorrect Password", "Warning");
                }
            }
            con.Close();
        }

        private void UpdatePassword_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(CurrentPasswordBox.Text) || string.IsNullOrEmpty(NewPasswordBox.Text)) 
            {
                MessageBox.Show("Empty password fields", "Warning");
            }
            else
            {
                try
                {
                    UpdatePass();
                }catch(SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
