﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finals
{
    public partial class CustomerCode : Form
    {
        TextBox customerCodeBox;
        public CustomerCode(TextBox textbox)
        {
            InitializeComponent();

            //string sql = "select person.person.BusinessEntityID as 'ID',concat(FirstName,' ',LastName) as 'Name',AccountNumber as 'Account Number',concat(AddressLine1,', ',city) as 'City',concat(person.stateprovince.name,',',CountryRegionCode) as 'Country',PostalCode as 'Postal Code',EmailAddress as 'Email' from person.Person join sales.Customer on Person.person.BusinessEntityID = sales.Customer.PersonID join person.BusinessEntityAddress on person.BusinessEntityAddress.BusinessEntityID = person.person.BusinessEntityID join person.Address on person.BusinessEntityAddress.BusinessEntityID = person.address.AddressID join person.EmailAddress on person.person.BusinessEntityID = person.emailaddress.BusinessEntityID join person.StateProvince on person.address.StateProvinceID = person.stateprovince.StateProvinceID";
            
            //for optimization purposes
            string sql = "select top(100) person.person.BusinessEntityID as 'ID',concat(FirstName,' ',LastName) as 'Name',AccountNumber as 'Account Number',concat(AddressLine1,', ',city) as 'City',concat(person.stateprovince.name,',',CountryRegionCode) as 'Country',PostalCode as 'Postal Code',EmailAddress as 'Email' from person.Person join sales.Customer on Person.person.BusinessEntityID = sales.Customer.PersonID join person.BusinessEntityAddress on person.BusinessEntityAddress.BusinessEntityID = person.person.BusinessEntityID join person.Address on person.BusinessEntityAddress.BusinessEntityID = person.address.AddressID join person.EmailAddress on person.person.BusinessEntityID = person.emailaddress.BusinessEntityID join person.StateProvince on person.address.StateProvinceID = person.stateprovince.StateProvinceID";

            SqlConnection con;
            SqlCommand command;
            SqlDataAdapter da;
            con = new SqlConnection(Functions.GetConnectionString());
            con.Open();

            command = new SqlCommand(sql, con);
            da = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);
            CustomerGridView.DataSource = dt;

            //fix visuals of data grid view
            CustomerGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
            CustomerGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            CustomerGridView.Columns[0].Width = 60;
            CustomerGridView.Columns[1].Width = 150;
            CustomerGridView.Columns[2].Width = 100;
            CustomerGridView.Columns[3].Width = 255;
            CustomerGridView.Columns[4].Width = 150;
            CustomerGridView.Columns[5].Width = 75;
            CustomerGridView.Columns[6].Width = 265;

            customerCodeBox = textbox;
        }

        public void SearchName()
        {
            (CustomerGridView.DataSource as DataTable).DefaultView.RowFilter = string.Format("Name LIKE '%{0}%'", SearchBox.Text);
        }

        public void SearchCode()
        {
            BindingSource bs_sp = new BindingSource();

            bs_sp.DataSource = CustomerGridView.DataSource;
            bs_sp.Filter = "Convert(ID, 'System.String') like '" + SearchBoxCode.Text + "%'";
            CustomerGridView.DataSource = bs_sp;
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            SearchBoxCode.Text = "";
            SearchName();
        }

        private void CustomerGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                customerCodeBox.Text = CustomerGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                this.Dispose();
            }
            catch
            {

            }
            
        }

        private void SearchBoxCode_KeyDown(object sender, KeyEventArgs e)
        {
            SearchBox.Text = "";
            SearchCode();
        }
    }
}
