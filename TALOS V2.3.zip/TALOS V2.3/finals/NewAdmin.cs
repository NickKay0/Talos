﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace finals
{
    public partial class NewAdmin : Form
    {
        public NewAdmin()
        {
            InitializeComponent();

            PasswordBox.UseSystemPasswordChar = true;
            ConfirmPassword.UseSystemPasswordChar = true;
        }

        private void CreateBtn_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(UsernameBox.Text))
            {
                MessageBox.Show("Username field is empty", "Error");
            }else if(string.IsNullOrEmpty(PasswordBox.Text) || string.IsNullOrEmpty(ConfirmPassword.Text))
            {
                MessageBox.Show("Password field is empty", "Error");
            }else if(PasswordBox.Text != ConfirmPassword.Text)
            {
                MessageBox.Show("Passwords do not match", "Error");
            }
            else
            {
                try
                {
                    CreateAdmin();
                }catch(SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        void CreateAdmin()
        {
            SqlConnection con = new SqlConnection(Functions.GetConnectionString());
            SqlCommand command;
            SqlDataReader reader;
            string sql = $"select username from login where username = '{UsernameBox.Text}'";
            con.Open();
            
            command = new SqlCommand(sql, con);
            reader= command.ExecuteReader();
            if(reader.HasRows)
            {
                MessageBox.Show("Username already exists","Error");
            }
            else
            {
                sql = $"insert into login(username,password) values ('{UsernameBox.Text}','{PasswordBox.Text}')";
                command = new SqlCommand(sql, con);
                command.CommandType = CommandType.Text;
                command.ExecuteNonQuery();
                MessageBox.Show("Username succesfully created", "Success");
            }
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            ConfirmPassword.UseSystemPasswordChar = false;
        }

        private void button2_MouseUp(object sender, MouseEventArgs e)
        {
            ConfirmPassword.UseSystemPasswordChar = true;
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            PasswordBox.UseSystemPasswordChar = false;
        }

        private void button1_MouseUp(object sender, MouseEventArgs e)
        {
            PasswordBox.UseSystemPasswordChar = true;
        }
    }
}
