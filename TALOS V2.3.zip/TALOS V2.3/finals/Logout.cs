﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finals
{
    public partial class Logout : Form
    {
        Form home;
        public Logout(Form home)
        {
            InitializeComponent();
            this.home = home;
        }

        private void LogoutButton_Click(object sender, EventArgs e)
        {
            this.Close();
            LoginScreen ls = new LoginScreen();
            home.Hide();
            ls.ShowDialog();
            home.Close();
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            home.Close();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
