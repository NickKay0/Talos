﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finals
{
    internal class CustomExceptionHandling
    {
        public class InvalidSPIDException : Exception
        {
            public InvalidSPIDException() { }
        }

        public class InvalidEmployeeIDException : Exception
        {
            public InvalidEmployeeIDException() { }
        }

        public class AlreadyExists : Exception
        {
            public AlreadyExists() { }
        }
    }
}
