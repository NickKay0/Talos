﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finals
{
    public partial class NewEmployee : Form
    {
        public NewEmployee()
        {
            InitializeComponent();

            AddressTypeBox.SelectedIndex = 0;
            PromotionBox.SelectedIndex = 0;
            PhoneTypeBox.SelectedIndex = 0;
            GenderBox.SelectedIndex = 0;
            MaritalStatusBox.SelectedIndex = 0;
        }

        private void MiddleNameBox_Enter(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(MiddleNameBox.Text) || MiddleNameBox.Text.Equals(" Optional"))
            {
                MiddleNameBox.Text = "";
                MiddleNameBox.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                MiddleNameBox.ForeColor = Color.Gainsboro;
            }
        }

        private void MiddleNameBox_Leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(MiddleNameBox.Text))
            {
                MiddleNameBox.Text = " Optional";
                MiddleNameBox.Font = new Font("Segoe UI Light", 12, FontStyle.Italic);
                MiddleNameBox.ForeColor = Color.FromArgb(73, 80, 107);
            }
        }

        private void TitleBox_Enter(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(TitleBox.Text) || TitleBox.Text.Equals(" Optional"))
            {
                TitleBox.Text = "";
                TitleBox.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                TitleBox.ForeColor = Color.Gainsboro;
            }
        }

        private void TitleBox_Leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(TitleBox.Text))
            {
                TitleBox.Text = " Optional";
                TitleBox.Font = new Font("Segoe UI Light", 12, FontStyle.Italic);
                TitleBox.ForeColor = Color.FromArgb(73, 80, 107);
            }
        }

        private void SuffixBox_Enter(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(SuffixBox.Text) || SuffixBox.Text.Equals(" Optional"))
            {
                SuffixBox.Text = "";
                SuffixBox.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                SuffixBox.ForeColor = Color.Gainsboro;
            }
        }

        private void SuffixBox_Leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(SuffixBox.Text))
            {
                SuffixBox.Text = " Optional";
                SuffixBox.Font = new Font("Segoe UI Light", 12, FontStyle.Italic);
                SuffixBox.ForeColor = Color.FromArgb(73, 80, 107);
            }
        }

        private void SecondaryAddressBox_Enter(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(SecondaryAddressBox.Text) || SecondaryAddressBox.Text.Equals(" Optional"))
            {
                SecondaryAddressBox.Text = "";
                SecondaryAddressBox.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                SecondaryAddressBox.ForeColor = Color.Gainsboro;
            }
        }

        private void SecondaryAddressBox_Leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(SecondaryAddressBox.Text))
            {
                SecondaryAddressBox.Text = " Optional";
                SecondaryAddressBox.Font = new Font("Segoe UI Light", 12, FontStyle.Italic);
                SecondaryAddressBox.ForeColor = Color.FromArgb(73, 80, 107);
            }
        }

        private void EmailBox_Enter(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(EmailBox.Text) || EmailBox.Text.Equals(" Optional"))
            {
                EmailBox.Text = "";
                EmailBox.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                EmailBox.ForeColor = Color.Gainsboro;
            }
        }

        private void EmailBox_Leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(EmailBox.Text))
            {
                EmailBox.Text = " Optional";
                EmailBox.Font = new Font("Segoe UI Light", 12, FontStyle.Italic);
                EmailBox.ForeColor = Color.FromArgb(73, 80, 107);
            }
        }


        public void CreateNewEmployee()
        {
            try
            {
                int businessEntityId = 0, addressId = 0, addressTypeId = 0;
                string connectionString = Functions.GetConnectionString();
                SqlConnection con;
                SqlCommand command;
                SqlDataReader dataReader;

                con = new SqlConnection(connectionString);
                con.Open();

                //get all of the inputs
                string title, fname, mname, lname, suffix, mainAddress, secondaryAddress, email, phoneNumber = "", city, postalCode;
                string nationalid,jobtitle,loginid,birthdate,hiredate;
                char gender, maritalStatus;
                int promotion = 0, nameStyle = 0, territory = 0, phoneType = 0, stateProvinceId = 0, addressType = 0;
                bool validProvinceId = true, validPhone = true, provinceIdExists = false;

                title = TitleBox.Text;
                fname = FirstNameBox.Text;
                mname = MiddleNameBox.Text;
                lname = LastNameBox.Text;
                suffix = SuffixBox.Text;
                mainAddress = MainAddressBox.Text;
                secondaryAddress = SecondaryAddressBox.Text;
                email = EmailBox.Text;
                city = CityBox.Text;
                postalCode = PostalCodeBox.Text;
                promotion = PromotionBox.SelectedIndex;
                nameStyle = NameStyleBox.Checked ? 1 : 0;
                phoneType = PhoneTypeBox.SelectedIndex + 1;
                addressType = AddressTypeBox.SelectedIndex + 1;

                nationalid = NationalIDBox.Text;
                jobtitle = JobTitleBox.Text;
                loginid = LoginIDBox.Text;
                birthdate = BirthFatePicker.Value.ToString("yyyy-MM-dd");
                hiredate = HireDatePicker.Value.ToString("yyyy-MM-dd");
                if (GenderBox.SelectedIndex == 0) gender = 'M';
                else gender = 'F';

                if (MaritalStatusBox.SelectedIndex == 0) maritalStatus = 'M';
                else maritalStatus = 'S';

                if (TitleBox.Text == " Optional") title = null;
                if (MiddleNameBox.Text == " Optional") mname = null;
                if (SuffixBox.Text == " Optional") suffix = null;
                if (SecondaryAddressBox.Text == " Optional") secondaryAddress = "";

                //stateprovinceid
                try
                {
                    stateProvinceId = int.Parse(ProvinceIDBox.Text);

                    //check if it exists
                    command = new SqlCommand($"select StateProvinceID from person.StateProvince where StateProvinceID = {stateProvinceId}", con);
                    dataReader = command.ExecuteReader();
                    if (dataReader.Read())
                    {
                        provinceIdExists = true;
                    }
                    else
                    {
                        MessageBox.Show("State Province ID Does Not Exist.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Province Id Must Be A Number");
                    ProvinceIDBox.Text = "";
                    validProvinceId = false;
                }

                //read phoneNumber and validate it
                try
                {
                    long.Parse(PhoneNumberBox.Text);
                    phoneNumber = PhoneNumberBox.Text;
                }
                catch
                {
                    MessageBox.Show("Phone Number Must Be Only Numerals");
                    validPhone = false;
                    PhoneNumberBox.Text = "";
                }

                if( provinceIdExists && validProvinceId && validPhone && fname.Length > 0 && lname.Length > 0 && mainAddress.Length > 0 && city.Length > 0 && postalCode.Length > 0 && nationalid.Length>0 && jobtitle.Length>0 && loginid.Length>0)
                {
                    //create person.BusinessEntity
                    command = new SqlCommand("insert into Person.BusinessEntity(rowguid) values (default)", con);
                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();

                    //get BusinessEntityId
                    command = new SqlCommand("select top(1) BusinessEntityID from Person.BusinessEntity order by BusinessEntityID desc", con);
                    dataReader = command.ExecuteReader();
                    if (dataReader.Read())
                    {
                        businessEntityId = dataReader.GetInt32(0);
                    }

                    //create person.person
                    command = new SqlCommand($"insert into person.Person(BusinessEntityID,PersonType,NameStyle,Title,FirstName,MiddleName,LastName,suffix,EmailPromotion,rowguid,ModifiedDate) " +
                        $"values((select businessentityid from Person.BusinessEntity where BusinessEntityID={businessEntityId}),'SP',{nameStyle},'{title}','{fname}','{mname}','{lname}','{suffix}',{promotion},default,default)", con);
                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();

                    //create Employee
                    command = new SqlCommand($"insert into HumanResources.Employee (BusinessEntityID,NationalIDNumber,LoginID,JobTitle,BirthDate,MaritalStatus,Gender,HireDate) values ((select BusinessEntityID from person.BusinessEntity where BusinessEntityID = {businessEntityId}),'{nationalid}','{loginid}','{jobtitle}','{birthdate}','{maritalStatus}','{gender}','{hiredate}')",con);
                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();

                    //create person.address
                    if (secondaryAddress.Length > 0)
                    {
                        command = new SqlCommand($"insert into person.address(AddressLine1,AddressLine2,city,StateProvinceID,PostalCode,rowguid, ModifiedDate) " +
                        $"values('{mainAddress}','{secondaryAddress}','{city}', (select StateProvinceID from person.StateProvince where StateProvinceID = {stateProvinceId}), '{postalCode}', default, default)", con);
                    }
                    else
                    {
                        command = new SqlCommand($"insert into person.address(AddressLine1,city,StateProvinceID,PostalCode,rowguid, ModifiedDate) " +
                        $"values('{mainAddress}','{city}', (select StateProvinceID from person.StateProvince where StateProvinceID = {stateProvinceId}), '{postalCode}', default, default)", con);
                    }
                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();

                    //get addressId
                    command = new SqlCommand("select top(1) addressid from person.Address order by AddressID desc", con);
                    dataReader = command.ExecuteReader();
                    if (dataReader.Read())
                    {
                        addressId = dataReader.GetInt32(0);
                    }

                    //create person.businessEntityAddress
                    command = new SqlCommand($"insert into person.BusinessEntityAddress (BusinessEntityID, AddressID, AddressTypeID, rowguid,ModifiedDate) " +
                        $"values( (select BusinessEntityID from Person.BusinessEntity where BusinessEntityID = {businessEntityId}), " +
                        $"(select AddressID from person.Address where AddressID = {addressId}), " +
                        $"(select AddressTypeID from person.AddressType where AddressTypeID = {addressType}), " +
                        $"default,default)", con);
                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();

                    //create person.emailAddress
                    if (email.Length > 0)
                    {
                        if(email != " Optional")
                        {
                            command = new SqlCommand($"insert into person.EmailAddress(BusinessEntityID,EmailAddress,rowguid,ModifiedDate) " +
                            $"values((select BusinessEntityID from person.BusinessEntity where BusinessEntityID = {businessEntityId}), " +
                            $"'{email}',default,default)", con);
                            command.CommandType = CommandType.Text;
                            command.ExecuteNonQuery();
                        }
                    }

                    //create person.phone
                    command = new SqlCommand($"insert into person.PersonPhone(BusinessEntityID,PhoneNumber,PhoneNumberTypeID,ModifiedDate)" +
                        $"values((select BusinessEntityID from Person.BusinessEntity where BusinessEntityID = {businessEntityId}), " +
                        $"'{phoneNumber}', " +
                        $"(select PhoneNumberTypeID from person.PhoneNumberType where PhoneNumberTypeID = {phoneType}), default)", con);
                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();

                    MessageBox.Show($"Salesperson Sucessfully Created With BusinessEntityID: {businessEntityId}");

                }
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CreateBtn_Click(object sender, EventArgs e)
        {
            CreateNewEmployee();
        }

        private void ProvinceIDHelpBtn_Click(object sender, EventArgs e)
        {
            ProvinceCode pc = new ProvinceCode(ProvinceIDBox);
            pc.Show();
        }
    }
}
