﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;

namespace finals
{
    public partial class NewSalesperson : Form
    {
        public NewSalesperson()
        {
            InitializeComponent();
            TerritoryBox.SelectedIndex = 0;
        }

        private void CreateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                CreateNewSalesperson();
            } catch (CustomExceptionHandling.InvalidEmployeeIDException)
            {
                MessageBox.Show("Invalid Employee ID", "Warning");
            } catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomExceptionHandling.AlreadyExists)
            {
                MessageBox.Show("ID already exists", "Warning");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void CreateNewSalesperson()
        {
            int businessEntityId = 0;
            if (!int.TryParse(EmployeeIDBox.Text, out int n) || string.IsNullOrEmpty(EmployeeIDBox.Text))
            {
                throw new CustomExceptionHandling.InvalidEmployeeIDException();
            }
            int employeeID = int.Parse(EmployeeIDBox.Text);
            int territoryID = TerritoryBox.SelectedIndex + 1;

            string quota, bonus;
            if (!string.IsNullOrEmpty(SalesQuotaBox.Text))
            {
                if (!double.TryParse(SalesQuotaBox.Text, out double nn))
                {
                    throw new Exception();
                }
                quota = double.Parse(SalesQuotaBox.Text).ToString();
            }else quota = "null";
            
            if(!string.IsNullOrEmpty(BonusBox.Text)) 
            {
                if (!double.TryParse(BonusBox.Text, out double nnn))
                {
                    throw new Exception();
                }
                bonus = double.Parse(BonusBox.Text).ToString();
            }
            else bonus = "default";
            
            SqlConnection con = new SqlConnection(Functions.GetConnectionString());
            SqlCommand command;
            SqlDataReader reader;
            con.Open();

            string sql = $"select businessentityid from humanresources.employee where businessentityid = {employeeID}";
            command = new SqlCommand(sql, con);
            reader = command.ExecuteReader();
            if(!reader.HasRows)
            {
                throw new CustomExceptionHandling.InvalidEmployeeIDException();
            }
            else
            {
                if(reader.Read())
                {
                    businessEntityId = reader.GetInt32(0);
                }
                sql = $"select businessentityid from sales.salesperson where businessentityid = {employeeID}";
                command = new SqlCommand (sql, con);
                reader = command.ExecuteReader();
                if(reader.HasRows)
                {
                    throw new CustomExceptionHandling.AlreadyExists();
                }
            }

            sql = $"insert into sales.SalesPerson (BusinessEntityID,TerritoryID,SalesQuota,Bonus) values((select BusinessEntityID from HumanResources.Employee where BusinessEntityID = {employeeID}),(select TerritoryID from sales.SalesTerritory where TerritoryID = {territoryID}),{quota},{bonus})";
            command = new SqlCommand (sql, con);
            command.CommandType = CommandType.Text;
            command.ExecuteNonQuery();

            sql = $"update HumanResources.Employee set JobTitle = 'Sales Representative' where BusinessEntityID = {employeeID}";
            command = new SqlCommand(sql, con);
            command.CommandType = CommandType.Text;
            command.ExecuteNonQuery();

            sql = $"update person.person set personType = 'SP' where businessentityid = {businessEntityId}";
            command = new SqlCommand(sql, con);
            command.CommandType = CommandType.Text;
            command.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Salesperson succesfully created with id: "+employeeID, "Success");
        }

        private void EmployeeIDHelpBtn_Click(object sender, EventArgs e)
        {
            EmployeeCode ec = new EmployeeCode(EmployeeIDBox);
            ec.Show();
        }
    }
}
