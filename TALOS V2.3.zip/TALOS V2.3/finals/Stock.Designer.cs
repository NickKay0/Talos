﻿namespace finals
{
    partial class Stock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Stock));
            this.StockGridView = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SearchBoxCode = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SearchBox = new System.Windows.Forms.TextBox();
            this.ShadowPanel1 = new System.Windows.Forms.Panel();
            this.ShadowPanel2 = new System.Windows.Forms.Panel();
            this.ShadowPanel3 = new System.Windows.Forms.Panel();
            this.ReorderAll = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SalespersonBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ReorderSelected = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.StockGridView)).BeginInit();
            this.ShadowPanel1.SuspendLayout();
            this.ShadowPanel2.SuspendLayout();
            this.ShadowPanel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // StockGridView
            // 
            this.StockGridView.AllowUserToAddRows = false;
            this.StockGridView.AllowUserToDeleteRows = false;
            this.StockGridView.AllowUserToResizeRows = false;
            this.StockGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(78)))), ((int)(((byte)(110)))));
            this.StockGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.StockGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.StockGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.StockGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.StockGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.StockGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.StockGridView.Location = new System.Drawing.Point(55, 66);
            this.StockGridView.Name = "StockGridView";
            this.StockGridView.ReadOnly = true;
            this.StockGridView.RowHeadersVisible = false;
            this.StockGridView.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.StockGridView.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.StockGridView.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(78)))), ((int)(((byte)(110)))));
            this.StockGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.StockGridView.ShowCellErrors = false;
            this.StockGridView.Size = new System.Drawing.Size(902, 563);
            this.StockGridView.TabIndex = 56;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(427, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 32);
            this.label1.TabIndex = 57;
            this.label1.Text = "View Stock";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(346, 656);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(231, 25);
            this.label2.TabIndex = 62;
            this.label2.Text = "Search By Product Code:";
            // 
            // SearchBoxCode
            // 
            this.SearchBoxCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.SearchBoxCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SearchBoxCode.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchBoxCode.ForeColor = System.Drawing.Color.Gainsboro;
            this.SearchBoxCode.Location = new System.Drawing.Point(0, 0);
            this.SearchBoxCode.Name = "SearchBoxCode";
            this.SearchBoxCode.Size = new System.Drawing.Size(104, 22);
            this.SearchBoxCode.TabIndex = 61;
            this.SearchBoxCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SearchBoxCode_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(50, 656);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(237, 25);
            this.label3.TabIndex = 60;
            this.label3.Text = "Search By Product Name:";
            // 
            // SearchBox
            // 
            this.SearchBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.SearchBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SearchBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.SearchBox.Location = new System.Drawing.Point(0, 0);
            this.SearchBox.Name = "SearchBox";
            this.SearchBox.Size = new System.Drawing.Size(232, 22);
            this.SearchBox.TabIndex = 59;
            this.SearchBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SearchBox_KeyDown);
            // 
            // ShadowPanel1
            // 
            this.ShadowPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.ShadowPanel1.Controls.Add(this.SearchBox);
            this.ShadowPanel1.Location = new System.Drawing.Point(55, 684);
            this.ShadowPanel1.Name = "ShadowPanel1";
            this.ShadowPanel1.Size = new System.Drawing.Size(234, 24);
            this.ShadowPanel1.TabIndex = 63;
            // 
            // ShadowPanel2
            // 
            this.ShadowPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.ShadowPanel2.Controls.Add(this.SearchBoxCode);
            this.ShadowPanel2.Location = new System.Drawing.Point(351, 684);
            this.ShadowPanel2.Name = "ShadowPanel2";
            this.ShadowPanel2.Size = new System.Drawing.Size(106, 24);
            this.ShadowPanel2.TabIndex = 64;
            // 
            // ShadowPanel3
            // 
            this.ShadowPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.ShadowPanel3.Controls.Add(this.ReorderAll);
            this.ShadowPanel3.Location = new System.Drawing.Point(782, 748);
            this.ShadowPanel3.Name = "ShadowPanel3";
            this.ShadowPanel3.Size = new System.Drawing.Size(175, 43);
            this.ShadowPanel3.TabIndex = 66;
            // 
            // ReorderAll
            // 
            this.ReorderAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.ReorderAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ReorderAll.FlatAppearance.BorderSize = 0;
            this.ReorderAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReorderAll.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.ReorderAll.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.ReorderAll.Location = new System.Drawing.Point(0, 0);
            this.ReorderAll.Name = "ReorderAll";
            this.ReorderAll.Size = new System.Drawing.Size(172, 40);
            this.ReorderAll.TabIndex = 57;
            this.ReorderAll.Text = "Reorder All";
            this.ReorderAll.UseVisualStyleBackColor = false;
            this.ReorderAll.Click += new System.EventHandler(this.ReorderAll_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel1.Controls.Add(this.SalespersonBox);
            this.panel1.Location = new System.Drawing.Point(55, 776);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(140, 24);
            this.panel1.TabIndex = 68;
            // 
            // SalespersonBox
            // 
            this.SalespersonBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.SalespersonBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SalespersonBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalespersonBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.SalespersonBox.Location = new System.Drawing.Point(0, 0);
            this.SalespersonBox.Name = "SalespersonBox";
            this.SalespersonBox.Size = new System.Drawing.Size(138, 22);
            this.SalespersonBox.TabIndex = 61;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(50, 748);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 25);
            this.label4.TabIndex = 67;
            this.label4.Text = "Salesperson ID:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel2.Controls.Add(this.ReorderSelected);
            this.panel2.Location = new System.Drawing.Point(782, 663);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(175, 43);
            this.panel2.TabIndex = 69;
            // 
            // ReorderSelected
            // 
            this.ReorderSelected.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.ReorderSelected.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ReorderSelected.FlatAppearance.BorderSize = 0;
            this.ReorderSelected.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReorderSelected.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.ReorderSelected.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.ReorderSelected.Location = new System.Drawing.Point(0, 0);
            this.ReorderSelected.Name = "ReorderSelected";
            this.ReorderSelected.Size = new System.Drawing.Size(172, 40);
            this.ReorderSelected.TabIndex = 57;
            this.ReorderSelected.Text = "Reorder Selected";
            this.ReorderSelected.UseVisualStyleBackColor = false;
            this.ReorderSelected.Click += new System.EventHandler(this.ReorderSelected_Click);
            // 
            // Stock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1006, 814);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ShadowPanel3);
            this.Controls.Add(this.ShadowPanel2);
            this.Controls.Add(this.ShadowPanel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.StockGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Stock";
            this.Text = "View Stock";
            ((System.ComponentModel.ISupportInitialize)(this.StockGridView)).EndInit();
            this.ShadowPanel1.ResumeLayout(false);
            this.ShadowPanel1.PerformLayout();
            this.ShadowPanel2.ResumeLayout(false);
            this.ShadowPanel2.PerformLayout();
            this.ShadowPanel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView StockGridView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox SearchBoxCode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox SearchBox;
        private System.Windows.Forms.Panel ShadowPanel1;
        private System.Windows.Forms.Panel ShadowPanel2;
        private System.Windows.Forms.Panel ShadowPanel3;
        private System.Windows.Forms.Button ReorderAll;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox SalespersonBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button ReorderSelected;
    }
}