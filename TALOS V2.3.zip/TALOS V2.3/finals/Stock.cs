﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finals
{
    public partial class Stock : Form
    {
        public Stock()
        {
            InitializeComponent();

            try
            {
                string sql = "select Production.product.ProductID as 'Code', name as 'Name', ProductNumber as 'Product Number', color as 'Color', ListPrice as 'Price', concat(size, SizeUnitMeasureCode) as 'Size', concat(weight,WeightUnitMeasureCode) as 'Weight', (select sum(Quantity) from Production.ProductInventory where Production.ProductInventory.ProductID = Production.Product.ProductID) as 'Stock',ReorderPoint as 'Reorder Point',SafetyStockLevel as 'Safety Stock',Description from Production.Product left join Production.ProductInventory on Production.Product.ProductID = production.ProductInventory.ProductID left join Production.ProductDescription on ProductDescription.ProductDescriptionID = Product.ProductID group by production.product.ProductID,name,ProductNumber,color,listprice,Size,SizeUnitMeasureCode,Weight,WeightUnitMeasureCode,Description,ReorderPoint,SafetyStockLevel";
                SqlConnection con;
                SqlCommand command;
                SqlDataAdapter da;
                con = new SqlConnection(Functions.GetConnectionString());
                con.Open();

                command = new SqlCommand(sql, con);
                da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                StockGridView.DataSource = dt;

                //fix visuals of datagridview
                StockGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                StockGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                StockGridView.Columns[0].Width = 60;
                StockGridView.Columns[1].Width = 200;
                StockGridView.Columns[2].Width = 82;
                StockGridView.Columns[3].Width = 55;
                StockGridView.Columns[4].Width = 80;
                StockGridView.Columns[5].Width = 65;
                StockGridView.Columns[6].Width = 80;
                StockGridView.Columns[7].Width = 65;
                StockGridView.Columns[8].Width = 65;
                StockGridView.Columns[9].Width = 65;
                StockGridView.Columns[10].Width = 1000;
            }
            catch(SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        public void SearchName()
        {
            (StockGridView.DataSource as DataTable).DefaultView.RowFilter = string.Format("Name LIKE '%{0}%'", SearchBox.Text);
        }

        public void SearchCode()
        {
            BindingSource bs_sp = new BindingSource();

            bs_sp.DataSource = StockGridView.DataSource;
            bs_sp.Filter = "Convert(Code, 'System.String') like '" + SearchBoxCode.Text + "%'";
            StockGridView.DataSource = bs_sp;
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            SearchBoxCode.Text = "";
            SearchName();
        }

        private void SearchBoxCode_KeyDown(object sender, KeyEventArgs e)
        {
            SearchBox.Text = "";
            SearchCode();
        }

        private void ReorderAll_Click(object sender, EventArgs e)
        {
            string salesPersonID = SalespersonBox.Text;

            List<int> selectedCodes = new List<int>();

            List<int> tillSafetyLevelPerCode = new List<int>();
            List<ProductToReorder> reorders = new List<ProductToReorder>();
            string sql;
            try
            {
                SqlConnection con;
                SqlCommand command;
                SqlDataReader reader;
                con = new SqlConnection(Functions.GetConnectionString());
                con.Open();

                //verify spid
                if (!int.TryParse(salesPersonID, out int n) || string.IsNullOrEmpty(salesPersonID)) throw new CustomExceptionHandling.InvalidSPIDException();
                sql = $"select businessentityid from sales.salesperson where businessentityid = {salesPersonID}";
                command = new SqlCommand(sql, con);
                reader = command.ExecuteReader();
                if (!reader.HasRows) throw new CustomExceptionHandling.InvalidSPIDException();

                sql = "select product.productid from production.Product join production.ProductInventory on production.ProductInventory.ProductID = production.Product.ProductID group by product.productid, ReorderPoint having ReorderPoint - sum(Quantity) > 0 and sum(Quantity) > -1";
                command = new SqlCommand(sql, con);
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    selectedCodes.Add(reader.GetInt32(0));
                }

                //Clipboard.Clear();

                //reorder
                for (int i = 0; i < selectedCodes.Count; i++)
                {
                    sql = $"select SafetyStockLevel,sum(Quantity) from production.product join production.ProductInventory on Production.ProductInventory.ProductID = production.product.ProductID where product.productid = {selectedCodes[i]} group by safetystocklevel";
                    command = new SqlCommand(sql, con);
                    reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        int amountTillSafetyLevel = reader.GetInt16(0) - reader.GetInt32(1);
                        int currentQuantity = reader.GetInt32(1);
                        tillSafetyLevelPerCode.Add(amountTillSafetyLevel);
                        sql = $"select LocationID from production.ProductInventory where ProductID = {selectedCodes[i]} order by quantity asc";
                        command = new SqlCommand(sql, con);
                        reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            sql = $"update production.ProductInventory set quantity = {amountTillSafetyLevel + currentQuantity} where locationid = {reader.GetInt16(0)} and productid = {selectedCodes[i]}";
                            command = new SqlCommand(sql, con);
                            command.CommandType = CommandType.Text;
                            command.ExecuteNonQuery();
                        }
                    }

                    //fill ProductToReorder.cs
                    sql = $"select top(1) AverageLeadTime,StandardPrice,purchasing.vendor.BusinessEntityID from purchasing.productvendor join purchasing.vendor on purchasing.vendor.BusinessEntityID = purchasing.ProductVendor.BusinessEntityID where purchasing.vendor.ActiveFlag = 1 and productid = {selectedCodes[i]} order by purchasing.Vendor.PreferredVendorStatus desc, standardprice asc";
                    command = new SqlCommand(sql, con);
                    reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        reorders.Add(new ProductToReorder(selectedCodes[i], tillSafetyLevelPerCode[i], reader.GetInt32(2), reader.GetInt32(0), double.Parse(reader.GetSqlMoney(1).ToString())));
                    }

                }

                int purchaseOrderId = 0;
                for (int i = 0; i < reorders.Count; i++)
                {
                    List<int> duplicateVendorsID = new List<int>();

                    if (duplicateVendorsID.Count == 0 || duplicateVendorsID.IndexOf(reorders[i].vendorId) == -1)
                    {
                        //do purchasing.purchaseorderheader stuff
                        duplicateVendorsID.Add(reorders[i].vendorId);
                        sql = $"insert into purchasing.purchaseorderheader (revisionnumber,status,employeeid,vendorid,shipmethodid,freight,orderdate,shipdate,modifieddate) values (default,default,(select businessentityid from humanresources.employee where businessentityid = {salesPersonID}),(select businessentityid from purchasing.vendor where businessentityid = {reorders[i].vendorId}),(select shipmethodid from purchasing.shipmethod where shipmethodid = 1),3.95,default,dateadd(day,{reorders[i].daysTillDelivery},GETDATE()),default)";
                        command = new SqlCommand(sql, con);
                        command.CommandType = CommandType.Text;
                        //Clipboard.SetText(Clipboard.GetText() + "\n" + sql + "\n" + reorders[0].ToString());
                        command.ExecuteNonQuery();

                        //get purchaseorderid
                        sql = $"select top(1) purchaseorderid from purchasing.purchaseorderheader order by purchaseorderid desc";
                        command = new SqlCommand(sql, con);
                        reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            purchaseOrderId = reader.GetInt32(0);
                        }
                    }

                    string unitPrice = reorders[i].standardPrice.ToString();
                    unitPrice = unitPrice.Replace(',', '.');
                    sql = $"insert into purchasing.PurchaseOrderDetail (PurchaseOrderID,DueDate,OrderQty,ProductID,UnitPrice,ReceivedQty,RejectedQty,ModifiedDate) values ((select PurchaseOrderID from Purchasing.PurchaseOrderHeader where purchaseorderid = {purchaseOrderId}),dateadd(day,{reorders[i].daysTillDelivery},GETDATE()),{reorders[i].amountTillSafetyLevel},{reorders[i].code},{unitPrice},{reorders[i].amountTillSafetyLevel},0,default)";
                    command = new SqlCommand(sql, con);
                    command.CommandType = CommandType.Text;
                    //Clipboard.SetText(Clipboard.GetText() + "\n" + sql + "\n" + reorders[0].ToString());
                    command.ExecuteNonQuery();
                }
                MessageBox.Show("The Codes Succesfully Reordered.", "Success");

                con.Close();
            }
            catch (CustomExceptionHandling.InvalidSPIDException)
            {
                MessageBox.Show("Invalid Salesperson ID.", "Warning");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ReorderSelected_Click(object sender, EventArgs e)
        {
            string salesPersonID = SalespersonBox.Text;

            List<int> selectedCodes = new List<int>();

            List<int> tillSafetyLevelPerCode = new List<int>();
            List<ProductToReorder> reorders = new List<ProductToReorder>();
            string sql;
            try
            {
                SqlConnection con;
                SqlCommand command;
                SqlDataReader reader;
                con = new SqlConnection(Functions.GetConnectionString());
                con.Open();

                //verify spid
                if (!int.TryParse(salesPersonID, out int n) || string.IsNullOrEmpty(salesPersonID)) throw new CustomExceptionHandling.InvalidSPIDException();
                sql = $"select businessentityid from sales.salesperson where businessentityid = {salesPersonID}";
                command = new SqlCommand(sql, con);
                reader = command.ExecuteReader();
                if (!reader.HasRows) throw new CustomExceptionHandling.InvalidSPIDException();

                for (int i = 0; i < StockGridView.SelectedRows.Count; i++)
                {
                    selectedCodes.Add(Convert.ToInt32(StockGridView.SelectedRows[i].Cells[0].Value));
                }

                //Clipboard.Clear();

                //reorder
                for (int i = 0; i < selectedCodes.Count; i++)
                {
                    sql = $"select SafetyStockLevel,sum(Quantity) from production.product join production.ProductInventory on Production.ProductInventory.ProductID = production.product.ProductID where product.productid = {selectedCodes[i]} group by safetystocklevel";
                    command = new SqlCommand(sql, con);
                    reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        int amountTillSafetyLevel = reader.GetInt16(0) - reader.GetInt32(1);
                        if(amountTillSafetyLevel < 0)
                        {
                            continue;
                        }

                        tillSafetyLevelPerCode.Add(amountTillSafetyLevel);
                        int currentQuantity = reader.GetInt32(1);
                        sql = $"select LocationID from production.ProductInventory where ProductID = {selectedCodes[i]} order by quantity asc";
                        command = new SqlCommand(sql, con);
                        reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            sql = $"update production.ProductInventory set quantity = {amountTillSafetyLevel + currentQuantity} where locationid = {reader.GetInt16(0)} and productid = {selectedCodes[i]}";
                            command = new SqlCommand(sql, con);
                            command.CommandType = CommandType.Text;
                            command.ExecuteNonQuery();
                        }
                    }

                    //fill ProductToReorder.cs
                    sql = $"select top(1) AverageLeadTime,StandardPrice,purchasing.vendor.BusinessEntityID from purchasing.productvendor join purchasing.vendor on purchasing.vendor.BusinessEntityID = purchasing.ProductVendor.BusinessEntityID where purchasing.vendor.ActiveFlag = 1 and productid = {selectedCodes[i]} order by purchasing.Vendor.PreferredVendorStatus desc, standardprice asc";
                    command = new SqlCommand(sql, con);
                    reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        reorders.Add(new ProductToReorder(selectedCodes[i], tillSafetyLevelPerCode[i], reader.GetInt32(2), reader.GetInt32(0), double.Parse(reader.GetSqlMoney(1).ToString())));
                    }

                }

                int purchaseOrderId = 0;
                for (int i = 0; i < reorders.Count; i++)
                {
                    List<int> duplicateVendorsID = new List<int>();

                    if (duplicateVendorsID.Count == 0 || duplicateVendorsID.IndexOf(reorders[i].vendorId) == -1)
                    {
                        //do purchasing.purchaseorderheader stuff
                        duplicateVendorsID.Add(reorders[i].vendorId);
                        sql = $"insert into purchasing.purchaseorderheader (revisionnumber,status,employeeid,vendorid,shipmethodid,freight,orderdate,shipdate,modifieddate) values (default,default,(select businessentityid from humanresources.employee where businessentityid = {salesPersonID}),(select businessentityid from purchasing.vendor where businessentityid = {reorders[i].vendorId}),(select shipmethodid from purchasing.shipmethod where shipmethodid = 1),3.95,default,dateadd(day,{reorders[i].daysTillDelivery},GETDATE()),default)";
                        command = new SqlCommand(sql, con);
                        command.CommandType = CommandType.Text;
                        //Clipboard.SetText(Clipboard.GetText() + "\n" + sql + "\n" + reorders[0].ToString());
                        command.ExecuteNonQuery();

                        //get purchaseorderid
                        sql = $"select top(1) purchaseorderid from purchasing.purchaseorderheader order by purchaseorderid desc";
                        command = new SqlCommand(sql, con);
                        reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            purchaseOrderId = reader.GetInt32(0);
                        }
                    }

                    string unitPrice = reorders[i].standardPrice.ToString();
                    unitPrice = unitPrice.Replace(',', '.');
                    sql = $"insert into purchasing.PurchaseOrderDetail (PurchaseOrderID,DueDate,OrderQty,ProductID,UnitPrice,ReceivedQty,RejectedQty,ModifiedDate) values ((select PurchaseOrderID from Purchasing.PurchaseOrderHeader where purchaseorderid = {purchaseOrderId}),dateadd(day,{reorders[i].daysTillDelivery},GETDATE()),{reorders[i].amountTillSafetyLevel},{reorders[i].code},{unitPrice},{reorders[i].amountTillSafetyLevel},0,default)";
                    command = new SqlCommand(sql, con);
                    command.CommandType = CommandType.Text;
                    //Clipboard.SetText(Clipboard.GetText() + "\n" + sql + "\n" + reorders[0].ToString());
                    command.ExecuteNonQuery();
                }
                MessageBox.Show("The Codes Succesfully Reordered.", "Success");

                con.Close();
            }
            catch (CustomExceptionHandling.InvalidSPIDException)
            {
                MessageBox.Show("Invalid Salesperson ID.", "Warning");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
