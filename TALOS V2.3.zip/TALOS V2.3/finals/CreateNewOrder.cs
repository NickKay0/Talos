﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finals
{
    public partial class CreateNewOrder : Form
    {

        int businessEntityID;
        List<CartItem> items;
        double total;

        double taxRate,deliveryFee,totalWithFees;

        public CreateNewOrder()
        {
            InitializeComponent();

            CartGridView.ScrollBars = ScrollBars.Vertical;
            CartGridView.Rows.Clear();
            items = new List<CartItem>();

            SameAddressBox.Checked = true;
            TerritoryBox.SelectedIndex = 0;

            ShippingMethodBox.SelectedIndex = 0;
            deliveryFee = 3.95;
            DeliveryFeeLabel.Text = "$"+deliveryFee.ToString();
        }

        private void AddToCartBtn_Click(object sender, EventArgs e)
        {
            string singlePrice = "";

            if(QuantityBox.Text == "")
            {
                QuantityBox.Text = "1";
            }
            //validate text boxes
            if (int.TryParse(ProductIDBox.Text, out int n))
            {
                if (int.TryParse(QuantityBox.Text, out int nn))
                {
                    //get name of the product id
                    bool validID = false;
                    string name = "";
                    int index = 0;

                    try
                    {
                        SqlConnection conn = new SqlConnection(Functions.GetConnectionString());
                        SqlCommand cmd;
                        SqlDataReader dataReader;
                        conn.Open();

                        string sql = $"select name from Production.Product where productid = {ProductIDBox.Text}";
                        cmd = new SqlCommand(sql, conn);

                        dataReader = cmd.ExecuteReader();
                        if (dataReader.Read())
                        {
                            name = dataReader.GetString(0);
                            validID = true;
                            index = int.Parse(ProductIDBox.Text);
                        }
                        else
                        {
                            MessageBox.Show("No Product Exists With This Code");
                            validID = false;
                        }

                        //get price of product
                        sql = $"select listprice from Production.Product where productid ={index}";
                        cmd = new SqlCommand (sql, conn);
                        dataReader = cmd.ExecuteReader();
                        if (dataReader.Read())
                        {
                            singlePrice = dataReader.GetSqlMoney(0).ToString();
                            total += (double.Parse(dataReader.GetSqlMoney(0).ToString())) * int.Parse(QuantityBox.Text);
                        }
                        TotalLabel.Text = "$"+total.ToString();
                        totalWithFees = (total + total * (taxRate / 100)) + deliveryFee;
                        TotalWithFeesLabel.Text = "$" + totalWithFees.ToString();

                        conn.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }

                    //fill the list
                    if(validID)
                    {
                        string price = ((double.Parse(singlePrice) * int.Parse(QuantityBox.Text))).ToString();
                        CartGridView.Rows.Add(ProductIDBox.Text, name, QuantityBox.Text, price);
                        items.Add(new CartItem(int.Parse(ProductIDBox.Text),int.Parse(QuantityBox.Text),double.Parse(singlePrice)));

                        ProductIDBox.Text = string.Empty;
                        QuantityBox.Text = string.Empty;
                    }

                }
                else MessageBox.Show("Invalid Quantity.", "Warning");
            }
            else MessageBox.Show("Invalid Code.", "Warning");
        }


        private void ConfirmCustomerBtn_Click(object sender, EventArgs e)
        {
            if(!int.TryParse(CustomerCodeBox.Text, out int n))
            {
                MessageBox.Show("Invalid Customer Code.", "Warning");
            }
            else
            {
                int id = int.Parse(CustomerCodeBox.Text);
                businessEntityID = id;
                string sql = $"select concat(FirstName,' ',LastName),CustomerID,AccountNumber,sales.CreditCard.CardNumber,AddressLine1,TaxRate,postalcode,city from sales.customer join person.person on person.person.BusinessEntityID = sales.Customer.PersonID join sales.PersonCreditCard on sales.PersonCreditCard.BusinessEntityID = sales.Customer.PersonID join sales.CreditCard on sales.CreditCard.CreditCardID = sales.PersonCreditCard.CreditCardID join person.BusinessEntityAddress on person.BusinessEntityAddress.BusinessEntityID = sales.Customer.PersonID join person.Address on person.Address.AddressID = Person.BusinessEntityAddress.AddressID left join sales.SalesTaxRate on sales.SalesTaxRate.StateProvinceID = person.address.StateProvinceID where sales.customer.PersonID = {id}";
                Clipboard.SetText(sql);
                try
                {
                    SqlConnection conn = new SqlConnection(Functions.GetConnectionString());
                    SqlCommand cmd;
                    SqlDataReader dataReader;
                    conn.Open();

                    cmd = new SqlCommand(sql, conn);
                    dataReader = cmd.ExecuteReader();
                    if(dataReader.Read())
                    {
                        CustomerNameBox.Text = dataReader.GetString(0);
                        AccountNumberBox.Text = dataReader.GetString(2);
                        CreditCardBox.Text = dataReader.GetString(3);
                        ShippingAddressBox.Text = dataReader.GetString(4);
                        BillingAddressBox.Text = dataReader.GetString(4);
                        try
                        {
                            taxRate = double.Parse(dataReader.GetSqlMoney(5).ToString());
                        }
                        catch (Exception ex)
                        {
                            taxRate = 0;
                        }
                        TaxRateLabel.Text = "%"+dataReader.GetSqlMoney(5).ToString();
                        PostalCodeBox.Text = dataReader.GetString(6);
                        CityBox.Text = dataReader.GetString(7);
                    }

                    totalWithFees = (total + total * (taxRate/100)) + deliveryFee;
                    TotalWithFeesLabel.Text = "$"+totalWithFees.ToString();

                    conn.Close();
                }
                catch(SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void ProductCodeHelpBtn_Click(object sender, EventArgs e)
        {
            ProductCodeID pci = new ProductCodeID(ProductIDBox);
            pci.Show();
        }

        private void CustomerHelpBtn_Click(object sender, EventArgs e)
        {
            CustomerCode cc = new CustomerCode(CustomerCodeBox);
            cc.Show();
        }

        private void ConfirmOrderBtn_Click(object sender, EventArgs e)
        {
            bool validSPID = true;
            bool filledSPID = false;
            int salesOrderID = 0;
            bool hasStock = false;

            //sales.salesorderheader var
            double taxAmt = total * (taxRate / 100);
            double freight = deliveryFee;
            int shipMethodID = ShippingMethodBox.SelectedIndex + 1;
            int territoryID = TerritoryBox.SelectedIndex + 1;
            string salespersonID = null;
            string accountNumber = AccountNumberBox.Text;
            string creditCard = CreditCardBox.Text;
            string shippingAddress = ShippingAddressBox.Text;
            string billingAddress = BillingAddressBox.Text;
            string postalCode = PostalCodeBox.Text;
            string dueDate = dateTimePicker.Value.ToString("yyyy-MM-dd HH:mm:ss:fff");
            string createdDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:fff");

            //get sp code
            string sql = $"select BusinessEntityID from sales.salesperson where BusinessEntityID = {SalespersonBox.Text}";
            if (int.TryParse(SalespersonBox.Text, out int nnn))
            {
                try
                {
                    SqlConnection conn = new SqlConnection(Functions.GetConnectionString());
                    SqlCommand cmd;
                    SqlDataReader dataReader;
                    conn.Open();

                    cmd = new SqlCommand(sql, conn);
                    dataReader = cmd.ExecuteReader();
                    if (dataReader.Read())
                    {
                        salespersonID = SalespersonBox.Text;
                        filledSPID = true;
                    }
                    else
                    {
                        salespersonID = null;
                        validSPID = false;
                        MessageBox.Show("Invalid SP Code");
                    }

                    conn.Close();
                }
                catch (SqlException ex)
                {

                }
            }
            else if (SalespersonBox.Text != " Optional")
            {
                MessageBox.Show("Invalid Salesperson ID!", "Warning");
                validSPID = false;
            }

            //validate if the cart items have stock and remove it from the location with the most
            List<int> codesToReorder = new List<int>();
            List<int> tillSafetyLevelPerCode = new List<int>();

            List<ProductToReorder> reorders = new List<ProductToReorder>();

            if (validSPID)
            {
                for (int i = 0; i < items.Count; i++)
                {
                    int quantity = items[i].qty;

                    sql = $"select sum(Quantity) from Production.ProductInventory where ProductID = {items[i].code}";
                    SqlConnection con;
                    SqlCommand command;
                    SqlDataReader reader;
                    con = new SqlConnection(Functions.GetConnectionString());
                    con.Open();

                    command = new SqlCommand(sql, con);
                    reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        if (reader.GetInt32(0) < items[i].qty)
                        {
                            MessageBox.Show("Stock Doesn't Have The Required Amount. Reorder?", "Warning");
                            hasStock = false;
                        }
                        else
                        {
                            hasStock = true;
                            sql = $"select locationid,quantity from production.ProductInventory where ProductID = {items[i].code} order by quantity desc";
                            command = new SqlCommand(sql, con);
                            reader = command.ExecuteReader();
                            while (reader.Read())
                            {
                                if (quantity > reader.GetInt16(1))
                                {
                                    //set the locationid's quantity to 0
                                    //move to next locationid
                                    quantity -= reader.GetInt16(1);
                                    sql = $"update production.ProductInventory set quantity = 0 where LocationID = {reader.GetInt16(0)}";

                                    command = new SqlCommand(sql, con);
                                    command.CommandType = CommandType.Text;
                                    command.ExecuteNonQuery();
                                }
                                else
                                {
                                    //set the locationid's quantity to locationid's quantity - quantity
                                    sql = $"update production.ProductInventory set quantity = {reader.GetInt16(1) - quantity} where LocationID = {reader.GetInt16(0)}";
                                    quantity = 0;

                                    command = new SqlCommand(sql, con);
                                    command.CommandType = CommandType.Text;
                                    command.ExecuteNonQuery();
                                    break;
                                }
                            }
                        }
                    }

                    //see which codes are below reorderpoint
                    sql = $"select ReorderPoint,sum(Quantity) from production.product join production.ProductInventory on Production.ProductInventory.ProductID = production.product.ProductID where production.product.productid = {items[i].code} group by production.product.ReorderPoint";
                    command = new SqlCommand(sql, con);
                    reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        if (reader.GetInt32(1) < reader.GetInt16(0))
                        {
                            codesToReorder.Add(items[i].code);
                        }
                    }

                    con.Close();
                }
                //ask for reorder
                if (codesToReorder.Count > 0)
                {
                    string showCodes = "";
                    for (int i = 0; i < codesToReorder.Count; i++)
                    {
                        showCodes += codesToReorder[i].ToString();
                        if (i < codesToReorder.Count - 1)
                        {
                            showCodes += ",";
                        }
                    }

                    DialogResult dr = MessageBox.Show($"The Codes {showCodes} Are Below The Safety Level.\nDo You Wish To Reorder?", "Warning", MessageBoxButtons.YesNo);
                    if (dr == DialogResult.Yes)
                    {
                        SqlConnection con;
                        SqlCommand command;
                        SqlDataReader reader;
                        con = new SqlConnection(Functions.GetConnectionString());
                        con.Open();

                        //reorder
                        for (int i = 0; i < codesToReorder.Count; i++)
                        {
                            sql = $"select SafetyStockLevel,sum(Quantity) from production.product join production.ProductInventory on Production.ProductInventory.ProductID = production.product.ProductID where production.product.productid = {codesToReorder[i]} group by production.product.SafetyStockLevel";
                            command = new SqlCommand(sql, con);
                            reader = command.ExecuteReader();
                            if (reader.Read())
                            {
                                int amountTillSafetyLevel = reader.GetInt16(0) - reader.GetInt32(1);
                                tillSafetyLevelPerCode.Add(amountTillSafetyLevel);
                                int qtyToOrder = amountTillSafetyLevel + amountTillSafetyLevel + reader.GetInt32(1);
                                sql = $"select LocationID from production.ProductInventory where ProductID = {codesToReorder[i]} order by quantity asc";
                                command = new SqlCommand(sql, con);
                                reader = command.ExecuteReader();
                                if (reader.Read())
                                {
                                    sql = $"update production.ProductInventory set quantity = {qtyToOrder} where locationid = {reader.GetInt16(0)} and productid = {codesToReorder[i]}";
                                    command = new SqlCommand(sql, con);
                                    command.CommandType = CommandType.Text;
                                    command.ExecuteNonQuery();
                                }
                            }

                            //fill ProductToReorder.cs
                            sql = $"select top(1) AverageLeadTime,StandardPrice,purchasing.vendor.BusinessEntityID from purchasing.productvendor join purchasing.vendor on purchasing.vendor.BusinessEntityID = purchasing.ProductVendor.BusinessEntityID where purchasing.vendor.ActiveFlag = 1 and productid = {codesToReorder[i]} order by purchasing.Vendor.PreferredVendorStatus desc, standardprice asc";
                            command = new SqlCommand(sql, con);
                            reader = command.ExecuteReader();
                            if (reader.Read())
                            {
                                reorders.Add(new ProductToReorder(codesToReorder[i], tillSafetyLevelPerCode[i], reader.GetInt32(2), reader.GetInt32(0), double.Parse(reader.GetSqlMoney(1).ToString())));
                            }

                        }

                        int purchaseOrderId = 0;
                        for (int i = 0; i < reorders.Count; i++)
                        {
                            List<int> duplicateVendorsID = new List<int>();

                            if (duplicateVendorsID.Count == 0 || duplicateVendorsID.IndexOf(reorders[i].vendorId) == -1)
                            {
                                //do purchasing.purchaseorderheader stuff
                                duplicateVendorsID.Add(reorders[i].vendorId);
                                //sql = $"insert into purchasing.purchaseorderheader (revisionnumber,status,employeeid,vendorid,shipmethodid,freight,orderdate,shipdate,modifieddate) values (default,default,(select businessentityid from humanresources.employee where businessentityid = {salespersonID}),(select businessentityid from purchasing.vendor where businessentityid = {reorders[i].vendorId}),(select shipmethodid from purchasing.shipmethod where shipmethodid = 1),3.95,default,{reorders[i].daysTillDelivery},GETDATE()),default)";
                                sql = $"insert into purchasing.purchaseorderheader (revisionnumber,status,employeeid,vendorid,shipmethodid,freight,orderdate,shipdate,modifieddate) values (default,default,(select businessentityid from humanresources.employee where businessentityid = {salespersonID}),(select businessentityid from purchasing.vendor where businessentityid = {reorders[i].vendorId}),(select shipmethodid from purchasing.shipmethod where shipmethodid = 1),3.95,default,dateadd(day,{reorders[i].daysTillDelivery},GETDATE()),default)";
                                command = new SqlCommand(sql, con);
                                command.CommandType = CommandType.Text;
                                command.ExecuteNonQuery();

                                //get purchaseorderid
                                sql = $"select top(1) purchaseorderid from purchasing.purchaseorderheader order by purchaseorderid desc";
                                command = new SqlCommand(sql, con);
                                reader = command.ExecuteReader();
                                if (reader.Read())
                                {
                                    purchaseOrderId = reader.GetInt32(0);
                                }
                            }

                            string unitPrice = reorders[i].amountTillSafetyLevel.ToString();
                            unitPrice.Replace(',', '.');
                            sql = $"insert into purchasing.PurchaseOrderDetail (PurchaseOrderID,DueDate,OrderQty,ProductID,UnitPrice,ReceivedQty,RejectedQty,ModifiedDate) values ((select PurchaseOrderID from Purchasing.PurchaseOrderHeader where purchaseorderid = {purchaseOrderId}),dateadd(day,{reorders[i].daysTillDelivery},GETDATE()),{unitPrice},{reorders[i].code},{reorders[i].standardPrice},{reorders[i].amountTillSafetyLevel},0,default)";
                            //Clipboard.SetText(sql);
                            command = new SqlCommand(sql, con);
                            command.CommandType = CommandType.Text;
                            command.ExecuteNonQuery();
                        }

                        MessageBox.Show("The Codes Succesfully Reordered.", "Success");
                        con.Close();
                    }
                }

                //do the insert for sales.salesorderheader
                if (!string.IsNullOrEmpty(CustomerCodeBox.Text) && items.Count > 0)
                {
                    try
                    {
                        SqlConnection conn = new SqlConnection(Functions.GetConnectionString());
                        SqlCommand cmd;
                        SqlDataReader dataReader;
                        conn.Open();

                        //execute the sales.salesorderheader sql
                        string totalStr = total.ToString().Replace(',','.');
                        string taxAmtStr = taxAmt.ToString().Replace(',', '.');
                        string DeliveryFeeStr = deliveryFee.ToString().Replace(',', '.');
                        sql = $"insert into sales.SalesOrderHeader(RevisionNumber,OrderDate,DueDate,Status,OnlineOrderFlag,CustomerID,TerritoryID,BillToAddressID,ShipToAddressID,ShipMethodID,CreditCardID,SubTotal,TaxAmt,Freight,rowguid,ModifiedDate,salespersonid) " +
                            $"values(default,default,'{dueDate}',default,0, (select CustomerID from sales.Customer where PersonID = {businessEntityID}), (select TerritoryID from sales.SalesTerritory where TerritoryID = {territoryID}), (select top(1) AddressID from person.Address where AddressLine1 = '{billingAddress}'), (select top(1) addressID from person.Address where AddressLine1 = '{shippingAddress}'), (select ShipMethodID from Purchasing.ShipMethod where ShipMethodID = {shipMethodID}), (select CreditCardID from sales.CreditCard where CardNumber = '{creditCard}'), {totalStr},{taxAmtStr},{DeliveryFeeStr},default,default,(select businessentityid from sales.salesperson where businessentityid = {salespersonID}))";
                        cmd = new SqlCommand(sql, conn);
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                     

                        //get max salesorderid
                        sql = "select top(1) SalesOrderID from sales.SalesOrderHeader order by salesorderid desc";
                        cmd = new SqlCommand(sql, conn);
                        dataReader = cmd.ExecuteReader();
                        if (dataReader.Read())
                        {
                            salesOrderID = dataReader.GetInt32(0);
                        }

                        //execute the sales.salesorderdetail sql
                        for (int i = 0; i < items.Count; i++)
                        {
                            string singlePieceStr = items[i].singlePrice.ToString().Replace(',','.'); ;
                            sql = $"insert into sales.SalesOrderDetail (SalesOrderID,OrderQty,ProductID,SpecialOfferID,UnitPrice,UnitPriceDiscount,rowguid,ModifiedDate) values ((select SalesOrderID from sales.SalesOrderHeader where SalesOrderID = {salesOrderID}),{items[i].qty},(select top(1) productid from sales.SpecialOfferProduct where productid = {items[i].code}),(select top(1) SpecialOfferID from sales.SpecialOfferProduct where ProductID = {items[i].code}),{singlePieceStr},default,default,default)";
                            cmd = new SqlCommand(sql, conn);
                            cmd.CommandType = CommandType.Text;
                            cmd.ExecuteNonQuery();
                        }

                        //update salesperson's quota
                        sql = "select SalesYTD from sales.SalesPerson where BusinessEntityID = " + salespersonID;
                        cmd = new SqlCommand (sql, conn);
                        dataReader = cmd.ExecuteReader();
                        string totalText = total.ToString();
                        totalText = totalText.Replace(',','.');
                        if(dataReader.Read())
                        {
                            string sales = (dataReader.GetSqlMoney(0).ToDouble() + double.Parse(totalText)).ToString().Replace(',','.');
                            sql = $"update sales.SalesPerson set SalesYTD = {sales} where BusinessEntityID = {salespersonID}";
                            cmd = new SqlCommand(sql,conn);
                            cmd.CommandType = CommandType.Text;
                            cmd.ExecuteNonQuery();
                        }

                        MessageBox.Show("The Order Succesfully Created With ID: " + salesOrderID, "Success");
                        SalespersonBox.Text = "";
                        CustomerCodeBox.Text = "";
                        CustomerNameBox.Text = "";
                        AccountNumberBox.Text = "";
                        CreditCardBox.Text = "";
                        ShippingAddressBox.Text = "";
                        BillingAddressBox.Text = "";
                        PostalCodeBox.Text = "";
                        CityBox.Text = "";

                        for(int i = 0; i <= CartGridView.Rows.Count; i++)
                        {
                            CartGridView.Rows.Remove(CartGridView.Rows[i]);
                            items.RemoveAt(i);
                            items.TrimExcess();
                        }

                        conn.Close();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else MessageBox.Show("Invalid SPID", "Warning.");
        }

        private void ProductIDBox_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                AddToCartBtn_Click(null,null);
            }
        }

        private void QuantityBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                AddToCartBtn_Click(null, null);
            }
        }

        private void RemoveFromCart_Click(object sender, EventArgs e)
        {
            try
            {
                int index = CartGridView.SelectedRows[0].Index;
                CartGridView.Rows.RemoveAt(index);
                items.RemoveAt(index);
                items.TrimExcess();
            }catch(ArgumentOutOfRangeException ex)
            {
                MessageBox.Show("Cart Is Empty");
            }
        }

        private void ShippingMethodBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(ShippingMethodBox.SelectedIndex){
                case 0:
                    deliveryFee = 3.95;
                    DeliveryFeeLabel.Text = "$"+deliveryFee.ToString();
                    break;
                case 1:
                    deliveryFee = 9.95;
                    DeliveryFeeLabel.Text = "$" + deliveryFee.ToString();
                    break;
                case 2:
                    deliveryFee = 29.95;
                    DeliveryFeeLabel.Text = "$" + deliveryFee.ToString();
                    break;
                case 3:
                    deliveryFee = 21.95;
                    DeliveryFeeLabel.Text = "$" + deliveryFee.ToString();
                    break;
                case 4:
                    deliveryFee = 8.99;
                    DeliveryFeeLabel.Text = "$" + deliveryFee.ToString();
                    break;
            }
            totalWithFees = (total + total * (taxRate / 100)) + deliveryFee;
            TotalWithFeesLabel.Text ="$" + totalWithFees.ToString();
        }

        private void SameAddressBox_CheckedChanged(object sender, EventArgs e)
        {
            if (SameAddressBox.Checked)
            {
                BillingAddressBox.ReadOnly = true;
                BillingAddressBox.BackColor = Color.FromArgb(54, 59, 84);
            }
            else
            {
                BillingAddressBox.ReadOnly = false;
                BillingAddressBox.BackColor = Color.FromArgb(39, 43, 61);
            }
        }
    }
}
