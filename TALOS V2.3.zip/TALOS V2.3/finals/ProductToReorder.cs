﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finals
{
    class ProductToReorder
    {
        public int code,amountTillSafetyLevel,vendorId,daysTillDelivery;
        public double standardPrice;

        public ProductToReorder(int code, int amountTillSafetyLevel, int vendorId, int daysTillDelivery, double standardPrice)
        {
            this.code = code;
            this.amountTillSafetyLevel = amountTillSafetyLevel;
            this.vendorId = vendorId;
            this.daysTillDelivery = daysTillDelivery;
            this.standardPrice = standardPrice;
        }

        public override string ToString()
        {
            return $"Code: {this.code},AmountTillSafetyLevel = {this.amountTillSafetyLevel},VendorID: {this.vendorId},DaysTillDelivery: {this.daysTillDelivery},StandardPrice = {this.standardPrice}";
        }
    }
}
