﻿namespace finals
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.ExitBtn = new System.Windows.Forms.Button();
            this.MinimizeBtn = new System.Windows.Forms.Button();
            this.WidgetPanel = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.MainPanel = new System.Windows.Forms.Panel();
            this.FooterPanel = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.LogoPanel = new System.Windows.Forms.Panel();
            this.SecondaryTextLabel = new System.Windows.Forms.Label();
            this.Divider1 = new System.Windows.Forms.Panel();
            this.UsernameLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CreateEntityBtn = new System.Windows.Forms.Button();
            this.ImageList = new System.Windows.Forms.ImageList(this.components);
            this.CreateEntitySubPanel = new System.Windows.Forms.Panel();
            this.OpenSeparateBtn7 = new System.Windows.Forms.Button();
            this.OpenSeparateBtn6 = new System.Windows.Forms.Button();
            this.OpenSeparateBtn1 = new System.Windows.Forms.Button();
            this.NewSalespersonBtn = new System.Windows.Forms.Button();
            this.NewEmployeeBtn = new System.Windows.Forms.Button();
            this.NewCustomerBtn = new System.Windows.Forms.Button();
            this.CreateOrderBtn = new System.Windows.Forms.Button();
            this.ViewBtn = new System.Windows.Forms.Button();
            this.ViewSubPanel = new System.Windows.Forms.Panel();
            this.OpenSeparateBtn5 = new System.Windows.Forms.Button();
            this.OpenSeparateBtn4 = new System.Windows.Forms.Button();
            this.OpenSeparateBtn3 = new System.Windows.Forms.Button();
            this.ViewOrderBtn = new System.Windows.Forms.Button();
            this.ViewCustomerBtn = new System.Windows.Forms.Button();
            this.ViewStockBtn = new System.Windows.Forms.Button();
            this.AdminBtn = new System.Windows.Forms.Button();
            this.AdminSubPanel = new System.Windows.Forms.Panel();
            this.CreateNewAdminBtn = new System.Windows.Forms.Button();
            this.ChangePasswordBtn = new System.Windows.Forms.Button();
            this.NavPanel = new System.Windows.Forms.Panel();
            this.SidePanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.CreateOrderSubpanel = new System.Windows.Forms.Panel();
            this.OpenSeparateBtn2 = new System.Windows.Forms.Button();
            this.CreateNewOrderBtn = new System.Windows.Forms.Button();
            this.AboutBtn = new System.Windows.Forms.Button();
            this.HomeBtn = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.WidgetPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.FooterPanel.SuspendLayout();
            this.LogoPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.CreateEntitySubPanel.SuspendLayout();
            this.ViewSubPanel.SuspendLayout();
            this.AdminSubPanel.SuspendLayout();
            this.SidePanel.SuspendLayout();
            this.CreateOrderSubpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // ExitBtn
            // 
            this.ExitBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ExitBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.ExitBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ExitBtn.BackgroundImage")));
            this.ExitBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ExitBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitBtn.FlatAppearance.BorderSize = 0;
            this.ExitBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ExitBtn.Location = new System.Drawing.Point(1203, 0);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(31, 28);
            this.ExitBtn.TabIndex = 1;
            this.ExitBtn.UseVisualStyleBackColor = false;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // MinimizeBtn
            // 
            this.MinimizeBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MinimizeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.MinimizeBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MinimizeBtn.BackgroundImage")));
            this.MinimizeBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.MinimizeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MinimizeBtn.FlatAppearance.BorderSize = 0;
            this.MinimizeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MinimizeBtn.Location = new System.Drawing.Point(1165, 0);
            this.MinimizeBtn.Name = "MinimizeBtn";
            this.MinimizeBtn.Size = new System.Drawing.Size(32, 28);
            this.MinimizeBtn.TabIndex = 2;
            this.MinimizeBtn.UseVisualStyleBackColor = false;
            this.MinimizeBtn.Click += new System.EventHandler(this.MinimizeBtn_Click);
            // 
            // WidgetPanel
            // 
            this.WidgetPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.WidgetPanel.Controls.Add(this.label5);
            this.WidgetPanel.Controls.Add(this.label4);
            this.WidgetPanel.Controls.Add(this.pictureBox2);
            this.WidgetPanel.Controls.Add(this.ExitBtn);
            this.WidgetPanel.Controls.Add(this.MinimizeBtn);
            this.WidgetPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.WidgetPanel.Location = new System.Drawing.Point(0, 0);
            this.WidgetPanel.Name = "WidgetPanel";
            this.WidgetPanel.Size = new System.Drawing.Size(1234, 28);
            this.WidgetPanel.TabIndex = 4;
            this.WidgetPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.WidgetPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.WidgetPanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(82, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 15);
            this.label5.TabIndex = 3;
            this.label5.Text = "V2.3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(32, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "TALOS";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(33, 34);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // MainPanel
            // 
            this.MainPanel.Location = new System.Drawing.Point(235, 28);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(999, 814);
            this.MainPanel.TabIndex = 5;
            // 
            // FooterPanel
            // 
            this.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.FooterPanel.Controls.Add(this.label3);
            this.FooterPanel.Location = new System.Drawing.Point(234, 841);
            this.FooterPanel.Name = "FooterPanel";
            this.FooterPanel.Size = new System.Drawing.Size(999, 20);
            this.FooterPanel.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(451, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "TALOS v2.3";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(22)))), ((int)(((byte)(38)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 830);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(231, 3);
            this.panel4.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(22)))), ((int)(((byte)(38)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(3, 830);
            this.panel2.TabIndex = 9;
            // 
            // LogoPanel
            // 
            this.LogoPanel.Controls.Add(this.SecondaryTextLabel);
            this.LogoPanel.Controls.Add(this.Divider1);
            this.LogoPanel.Controls.Add(this.UsernameLabel);
            this.LogoPanel.Controls.Add(this.pictureBox1);
            this.LogoPanel.Controls.Add(this.panel3);
            this.LogoPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.LogoPanel.Location = new System.Drawing.Point(3, 0);
            this.LogoPanel.Name = "LogoPanel";
            this.LogoPanel.Size = new System.Drawing.Size(228, 197);
            this.LogoPanel.TabIndex = 0;
            // 
            // SecondaryTextLabel
            // 
            this.SecondaryTextLabel.AutoSize = true;
            this.SecondaryTextLabel.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SecondaryTextLabel.ForeColor = System.Drawing.Color.DarkGray;
            this.SecondaryTextLabel.Location = new System.Drawing.Point(11, 168);
            this.SecondaryTextLabel.Name = "SecondaryTextLabel";
            this.SecondaryTextLabel.Size = new System.Drawing.Size(119, 15);
            this.SecondaryTextLabel.TabIndex = 2;
            this.SecondaryTextLabel.Text = "placeholder for text";
            // 
            // Divider1
            // 
            this.Divider1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(22)))), ((int)(((byte)(38)))));
            this.Divider1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Divider1.Location = new System.Drawing.Point(0, 195);
            this.Divider1.Name = "Divider1";
            this.Divider1.Size = new System.Drawing.Size(228, 2);
            this.Divider1.TabIndex = 0;
            // 
            // UsernameLabel
            // 
            this.UsernameLabel.AutoSize = true;
            this.UsernameLabel.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UsernameLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.UsernameLabel.Location = new System.Drawing.Point(9, 131);
            this.UsernameLabel.Name = "UsernameLabel";
            this.UsernameLabel.Size = new System.Drawing.Size(51, 25);
            this.UsernameLabel.TabIndex = 1;
            this.UsernameLabel.Text = "nikk";
            this.UsernameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(49, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(129, 116);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(22)))), ((int)(((byte)(38)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(228, 3);
            this.panel3.TabIndex = 3;
            // 
            // CreateEntityBtn
            // 
            this.CreateEntityBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.CreateEntityBtn.FlatAppearance.BorderSize = 0;
            this.CreateEntityBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CreateEntityBtn.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CreateEntityBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.CreateEntityBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreateEntityBtn.ImageIndex = 1;
            this.CreateEntityBtn.ImageList = this.ImageList;
            this.CreateEntityBtn.Location = new System.Drawing.Point(3, 240);
            this.CreateEntityBtn.Name = "CreateEntityBtn";
            this.CreateEntityBtn.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.CreateEntityBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.CreateEntityBtn.Size = new System.Drawing.Size(228, 43);
            this.CreateEntityBtn.TabIndex = 1;
            this.CreateEntityBtn.Text = "        Create Entity";
            this.CreateEntityBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreateEntityBtn.UseVisualStyleBackColor = true;
            this.CreateEntityBtn.Click += new System.EventHandler(this.CreateEntityBtn_Click);
            // 
            // ImageList
            // 
            this.ImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageList.ImageStream")));
            this.ImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.ImageList.Images.SetKeyName(0, "home_icon.png");
            this.ImageList.Images.SetKeyName(1, "create_user.png");
            this.ImageList.Images.SetKeyName(2, "pencil_icon.png");
            this.ImageList.Images.SetKeyName(3, "magn_glass_icon.png");
            this.ImageList.Images.SetKeyName(4, "create_admin.png");
            this.ImageList.Images.SetKeyName(5, "create_order_icon.png");
            this.ImageList.Images.SetKeyName(6, "ExclamationMarkIcon.png");
            // 
            // CreateEntitySubPanel
            // 
            this.CreateEntitySubPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(42)))), ((int)(((byte)(61)))));
            this.CreateEntitySubPanel.Controls.Add(this.OpenSeparateBtn7);
            this.CreateEntitySubPanel.Controls.Add(this.OpenSeparateBtn6);
            this.CreateEntitySubPanel.Controls.Add(this.OpenSeparateBtn1);
            this.CreateEntitySubPanel.Controls.Add(this.NewSalespersonBtn);
            this.CreateEntitySubPanel.Controls.Add(this.NewEmployeeBtn);
            this.CreateEntitySubPanel.Controls.Add(this.NewCustomerBtn);
            this.CreateEntitySubPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.CreateEntitySubPanel.Location = new System.Drawing.Point(3, 283);
            this.CreateEntitySubPanel.Name = "CreateEntitySubPanel";
            this.CreateEntitySubPanel.Size = new System.Drawing.Size(228, 90);
            this.CreateEntitySubPanel.TabIndex = 2;
            // 
            // OpenSeparateBtn7
            // 
            this.OpenSeparateBtn7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("OpenSeparateBtn7.BackgroundImage")));
            this.OpenSeparateBtn7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.OpenSeparateBtn7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.OpenSeparateBtn7.FlatAppearance.BorderSize = 0;
            this.OpenSeparateBtn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OpenSeparateBtn7.Font = new System.Drawing.Font("Nirmala UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpenSeparateBtn7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.OpenSeparateBtn7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.OpenSeparateBtn7.ImageList = this.ImageList;
            this.OpenSeparateBtn7.Location = new System.Drawing.Point(194, 61);
            this.OpenSeparateBtn7.Name = "OpenSeparateBtn7";
            this.OpenSeparateBtn7.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.OpenSeparateBtn7.Size = new System.Drawing.Size(25, 20);
            this.OpenSeparateBtn7.TabIndex = 17;
            this.OpenSeparateBtn7.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.OpenSeparateBtn7.UseVisualStyleBackColor = true;
            this.OpenSeparateBtn7.Click += new System.EventHandler(this.OpenSeparateBtn7_Click);
            // 
            // OpenSeparateBtn6
            // 
            this.OpenSeparateBtn6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("OpenSeparateBtn6.BackgroundImage")));
            this.OpenSeparateBtn6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.OpenSeparateBtn6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.OpenSeparateBtn6.FlatAppearance.BorderSize = 0;
            this.OpenSeparateBtn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OpenSeparateBtn6.Font = new System.Drawing.Font("Nirmala UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpenSeparateBtn6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.OpenSeparateBtn6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.OpenSeparateBtn6.ImageList = this.ImageList;
            this.OpenSeparateBtn6.Location = new System.Drawing.Point(194, 32);
            this.OpenSeparateBtn6.Name = "OpenSeparateBtn6";
            this.OpenSeparateBtn6.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.OpenSeparateBtn6.Size = new System.Drawing.Size(25, 20);
            this.OpenSeparateBtn6.TabIndex = 16;
            this.OpenSeparateBtn6.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.OpenSeparateBtn6.UseVisualStyleBackColor = true;
            this.OpenSeparateBtn6.Click += new System.EventHandler(this.OpenSeparateBtn6_Click);
            // 
            // OpenSeparateBtn1
            // 
            this.OpenSeparateBtn1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("OpenSeparateBtn1.BackgroundImage")));
            this.OpenSeparateBtn1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.OpenSeparateBtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.OpenSeparateBtn1.FlatAppearance.BorderSize = 0;
            this.OpenSeparateBtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OpenSeparateBtn1.Font = new System.Drawing.Font("Nirmala UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpenSeparateBtn1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.OpenSeparateBtn1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.OpenSeparateBtn1.ImageList = this.ImageList;
            this.OpenSeparateBtn1.Location = new System.Drawing.Point(194, 6);
            this.OpenSeparateBtn1.Name = "OpenSeparateBtn1";
            this.OpenSeparateBtn1.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.OpenSeparateBtn1.Size = new System.Drawing.Size(25, 20);
            this.OpenSeparateBtn1.TabIndex = 15;
            this.OpenSeparateBtn1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.OpenSeparateBtn1.UseVisualStyleBackColor = true;
            this.OpenSeparateBtn1.Click += new System.EventHandler(this.OpenSeparateBtn1_Click);
            // 
            // NewSalespersonBtn
            // 
            this.NewSalespersonBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NewSalespersonBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.NewSalespersonBtn.FlatAppearance.BorderSize = 0;
            this.NewSalespersonBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(82)))));
            this.NewSalespersonBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewSalespersonBtn.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewSalespersonBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.NewSalespersonBtn.Location = new System.Drawing.Point(0, 58);
            this.NewSalespersonBtn.Name = "NewSalespersonBtn";
            this.NewSalespersonBtn.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.NewSalespersonBtn.Size = new System.Drawing.Size(228, 29);
            this.NewSalespersonBtn.TabIndex = 2;
            this.NewSalespersonBtn.Text = "New Salesperson";
            this.NewSalespersonBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NewSalespersonBtn.UseVisualStyleBackColor = true;
            this.NewSalespersonBtn.Click += new System.EventHandler(this.NewEmployeeBtn_Click);
            // 
            // NewEmployeeBtn
            // 
            this.NewEmployeeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NewEmployeeBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.NewEmployeeBtn.FlatAppearance.BorderSize = 0;
            this.NewEmployeeBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(82)))));
            this.NewEmployeeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewEmployeeBtn.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewEmployeeBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.NewEmployeeBtn.Location = new System.Drawing.Point(0, 29);
            this.NewEmployeeBtn.Name = "NewEmployeeBtn";
            this.NewEmployeeBtn.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.NewEmployeeBtn.Size = new System.Drawing.Size(228, 29);
            this.NewEmployeeBtn.TabIndex = 1;
            this.NewEmployeeBtn.Text = "New Employee";
            this.NewEmployeeBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NewEmployeeBtn.UseVisualStyleBackColor = true;
            this.NewEmployeeBtn.Click += new System.EventHandler(this.NewSalespersonBtn_Click);
            // 
            // NewCustomerBtn
            // 
            this.NewCustomerBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NewCustomerBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.NewCustomerBtn.FlatAppearance.BorderSize = 0;
            this.NewCustomerBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(82)))));
            this.NewCustomerBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewCustomerBtn.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewCustomerBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.NewCustomerBtn.Location = new System.Drawing.Point(0, 0);
            this.NewCustomerBtn.Name = "NewCustomerBtn";
            this.NewCustomerBtn.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.NewCustomerBtn.Size = new System.Drawing.Size(228, 29);
            this.NewCustomerBtn.TabIndex = 0;
            this.NewCustomerBtn.Text = "New Customer";
            this.NewCustomerBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NewCustomerBtn.UseVisualStyleBackColor = true;
            this.NewCustomerBtn.Click += new System.EventHandler(this.NewCustomerBtn_Click);
            // 
            // CreateOrderBtn
            // 
            this.CreateOrderBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.CreateOrderBtn.FlatAppearance.BorderSize = 0;
            this.CreateOrderBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CreateOrderBtn.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CreateOrderBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.CreateOrderBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreateOrderBtn.ImageIndex = 5;
            this.CreateOrderBtn.ImageList = this.ImageList;
            this.CreateOrderBtn.Location = new System.Drawing.Point(3, 373);
            this.CreateOrderBtn.Name = "CreateOrderBtn";
            this.CreateOrderBtn.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.CreateOrderBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.CreateOrderBtn.Size = new System.Drawing.Size(228, 43);
            this.CreateOrderBtn.TabIndex = 3;
            this.CreateOrderBtn.Text = "        Create Order";
            this.CreateOrderBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreateOrderBtn.UseVisualStyleBackColor = true;
            this.CreateOrderBtn.Click += new System.EventHandler(this.CreateOrderBtn_Click);
            // 
            // ViewBtn
            // 
            this.ViewBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ViewBtn.FlatAppearance.BorderSize = 0;
            this.ViewBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ViewBtn.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.ViewBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ViewBtn.ImageIndex = 3;
            this.ViewBtn.ImageList = this.ImageList;
            this.ViewBtn.Location = new System.Drawing.Point(3, 446);
            this.ViewBtn.Name = "ViewBtn";
            this.ViewBtn.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.ViewBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ViewBtn.Size = new System.Drawing.Size(228, 43);
            this.ViewBtn.TabIndex = 4;
            this.ViewBtn.Text = "        View";
            this.ViewBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ViewBtn.UseVisualStyleBackColor = true;
            this.ViewBtn.Click += new System.EventHandler(this.ViewBtn_Click);
            // 
            // ViewSubPanel
            // 
            this.ViewSubPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(42)))), ((int)(((byte)(61)))));
            this.ViewSubPanel.Controls.Add(this.OpenSeparateBtn5);
            this.ViewSubPanel.Controls.Add(this.OpenSeparateBtn4);
            this.ViewSubPanel.Controls.Add(this.OpenSeparateBtn3);
            this.ViewSubPanel.Controls.Add(this.ViewOrderBtn);
            this.ViewSubPanel.Controls.Add(this.ViewCustomerBtn);
            this.ViewSubPanel.Controls.Add(this.ViewStockBtn);
            this.ViewSubPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.ViewSubPanel.Location = new System.Drawing.Point(3, 489);
            this.ViewSubPanel.Name = "ViewSubPanel";
            this.ViewSubPanel.Size = new System.Drawing.Size(228, 90);
            this.ViewSubPanel.TabIndex = 5;
            // 
            // OpenSeparateBtn5
            // 
            this.OpenSeparateBtn5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("OpenSeparateBtn5.BackgroundImage")));
            this.OpenSeparateBtn5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.OpenSeparateBtn5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.OpenSeparateBtn5.FlatAppearance.BorderSize = 0;
            this.OpenSeparateBtn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OpenSeparateBtn5.Font = new System.Drawing.Font("Nirmala UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpenSeparateBtn5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.OpenSeparateBtn5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.OpenSeparateBtn5.ImageList = this.ImageList;
            this.OpenSeparateBtn5.Location = new System.Drawing.Point(194, 64);
            this.OpenSeparateBtn5.Name = "OpenSeparateBtn5";
            this.OpenSeparateBtn5.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.OpenSeparateBtn5.Size = new System.Drawing.Size(25, 20);
            this.OpenSeparateBtn5.TabIndex = 19;
            this.OpenSeparateBtn5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.OpenSeparateBtn5.UseVisualStyleBackColor = true;
            this.OpenSeparateBtn5.Click += new System.EventHandler(this.OpenSeparateBtn5_Click);
            // 
            // OpenSeparateBtn4
            // 
            this.OpenSeparateBtn4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("OpenSeparateBtn4.BackgroundImage")));
            this.OpenSeparateBtn4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.OpenSeparateBtn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.OpenSeparateBtn4.FlatAppearance.BorderSize = 0;
            this.OpenSeparateBtn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OpenSeparateBtn4.Font = new System.Drawing.Font("Nirmala UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpenSeparateBtn4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.OpenSeparateBtn4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.OpenSeparateBtn4.ImageList = this.ImageList;
            this.OpenSeparateBtn4.Location = new System.Drawing.Point(194, 32);
            this.OpenSeparateBtn4.Name = "OpenSeparateBtn4";
            this.OpenSeparateBtn4.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.OpenSeparateBtn4.Size = new System.Drawing.Size(25, 20);
            this.OpenSeparateBtn4.TabIndex = 18;
            this.OpenSeparateBtn4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.OpenSeparateBtn4.UseVisualStyleBackColor = true;
            this.OpenSeparateBtn4.Click += new System.EventHandler(this.OpenSeparate4_Click);
            // 
            // OpenSeparateBtn3
            // 
            this.OpenSeparateBtn3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("OpenSeparateBtn3.BackgroundImage")));
            this.OpenSeparateBtn3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.OpenSeparateBtn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.OpenSeparateBtn3.FlatAppearance.BorderSize = 0;
            this.OpenSeparateBtn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OpenSeparateBtn3.Font = new System.Drawing.Font("Nirmala UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpenSeparateBtn3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.OpenSeparateBtn3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.OpenSeparateBtn3.ImageList = this.ImageList;
            this.OpenSeparateBtn3.Location = new System.Drawing.Point(194, 3);
            this.OpenSeparateBtn3.Name = "OpenSeparateBtn3";
            this.OpenSeparateBtn3.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.OpenSeparateBtn3.Size = new System.Drawing.Size(25, 20);
            this.OpenSeparateBtn3.TabIndex = 17;
            this.OpenSeparateBtn3.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.OpenSeparateBtn3.UseVisualStyleBackColor = true;
            this.OpenSeparateBtn3.Click += new System.EventHandler(this.OpenSeparateBtn3_Click);
            // 
            // ViewOrderBtn
            // 
            this.ViewOrderBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ViewOrderBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ViewOrderBtn.FlatAppearance.BorderSize = 0;
            this.ViewOrderBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(82)))));
            this.ViewOrderBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ViewOrderBtn.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewOrderBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.ViewOrderBtn.Location = new System.Drawing.Point(0, 58);
            this.ViewOrderBtn.Name = "ViewOrderBtn";
            this.ViewOrderBtn.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.ViewOrderBtn.Size = new System.Drawing.Size(228, 29);
            this.ViewOrderBtn.TabIndex = 2;
            this.ViewOrderBtn.Text = "View Order";
            this.ViewOrderBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ViewOrderBtn.UseVisualStyleBackColor = true;
            this.ViewOrderBtn.Click += new System.EventHandler(this.ViewOrderBtn_Click);
            // 
            // ViewCustomerBtn
            // 
            this.ViewCustomerBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ViewCustomerBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ViewCustomerBtn.FlatAppearance.BorderSize = 0;
            this.ViewCustomerBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(82)))));
            this.ViewCustomerBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ViewCustomerBtn.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewCustomerBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.ViewCustomerBtn.Location = new System.Drawing.Point(0, 29);
            this.ViewCustomerBtn.Name = "ViewCustomerBtn";
            this.ViewCustomerBtn.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.ViewCustomerBtn.Size = new System.Drawing.Size(228, 29);
            this.ViewCustomerBtn.TabIndex = 1;
            this.ViewCustomerBtn.Text = "View Entity";
            this.ViewCustomerBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ViewCustomerBtn.UseVisualStyleBackColor = true;
            this.ViewCustomerBtn.Click += new System.EventHandler(this.ViewCustomerBtn_Click);
            // 
            // ViewStockBtn
            // 
            this.ViewStockBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ViewStockBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ViewStockBtn.FlatAppearance.BorderSize = 0;
            this.ViewStockBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(82)))));
            this.ViewStockBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ViewStockBtn.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewStockBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.ViewStockBtn.Location = new System.Drawing.Point(0, 0);
            this.ViewStockBtn.Name = "ViewStockBtn";
            this.ViewStockBtn.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.ViewStockBtn.Size = new System.Drawing.Size(228, 29);
            this.ViewStockBtn.TabIndex = 0;
            this.ViewStockBtn.Text = "View Stock";
            this.ViewStockBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ViewStockBtn.UseVisualStyleBackColor = true;
            this.ViewStockBtn.Click += new System.EventHandler(this.ViewStockBtn_Click);
            // 
            // AdminBtn
            // 
            this.AdminBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.AdminBtn.FlatAppearance.BorderSize = 0;
            this.AdminBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AdminBtn.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.AdminBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AdminBtn.ImageIndex = 4;
            this.AdminBtn.ImageList = this.ImageList;
            this.AdminBtn.Location = new System.Drawing.Point(3, 579);
            this.AdminBtn.Name = "AdminBtn";
            this.AdminBtn.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.AdminBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.AdminBtn.Size = new System.Drawing.Size(228, 43);
            this.AdminBtn.TabIndex = 6;
            this.AdminBtn.Text = "        Admin";
            this.AdminBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AdminBtn.UseVisualStyleBackColor = true;
            this.AdminBtn.Click += new System.EventHandler(this.AdminBtn_Click);
            // 
            // AdminSubPanel
            // 
            this.AdminSubPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(42)))), ((int)(((byte)(61)))));
            this.AdminSubPanel.Controls.Add(this.CreateNewAdminBtn);
            this.AdminSubPanel.Controls.Add(this.ChangePasswordBtn);
            this.AdminSubPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.AdminSubPanel.Location = new System.Drawing.Point(3, 622);
            this.AdminSubPanel.Name = "AdminSubPanel";
            this.AdminSubPanel.Size = new System.Drawing.Size(228, 57);
            this.AdminSubPanel.TabIndex = 7;
            // 
            // CreateNewAdminBtn
            // 
            this.CreateNewAdminBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CreateNewAdminBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.CreateNewAdminBtn.FlatAppearance.BorderSize = 0;
            this.CreateNewAdminBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(82)))));
            this.CreateNewAdminBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CreateNewAdminBtn.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CreateNewAdminBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.CreateNewAdminBtn.Location = new System.Drawing.Point(0, 29);
            this.CreateNewAdminBtn.Name = "CreateNewAdminBtn";
            this.CreateNewAdminBtn.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.CreateNewAdminBtn.Size = new System.Drawing.Size(228, 29);
            this.CreateNewAdminBtn.TabIndex = 0;
            this.CreateNewAdminBtn.Text = "Register New Admin";
            this.CreateNewAdminBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreateNewAdminBtn.UseVisualStyleBackColor = true;
            this.CreateNewAdminBtn.Click += new System.EventHandler(this.CreateNewAdminBtn_Click);
            // 
            // ChangePasswordBtn
            // 
            this.ChangePasswordBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChangePasswordBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ChangePasswordBtn.FlatAppearance.BorderSize = 0;
            this.ChangePasswordBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(82)))));
            this.ChangePasswordBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChangePasswordBtn.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChangePasswordBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.ChangePasswordBtn.Location = new System.Drawing.Point(0, 0);
            this.ChangePasswordBtn.Name = "ChangePasswordBtn";
            this.ChangePasswordBtn.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.ChangePasswordBtn.Size = new System.Drawing.Size(228, 29);
            this.ChangePasswordBtn.TabIndex = 2;
            this.ChangePasswordBtn.Text = "Change Password";
            this.ChangePasswordBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ChangePasswordBtn.UseVisualStyleBackColor = true;
            this.ChangePasswordBtn.Click += new System.EventHandler(this.ChangePasswordBtn_Click);
            // 
            // NavPanel
            // 
            this.NavPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.NavPanel.Location = new System.Drawing.Point(173, 210);
            this.NavPanel.Name = "NavPanel";
            this.NavPanel.Size = new System.Drawing.Size(6, 30);
            this.NavPanel.TabIndex = 8;
            // 
            // SidePanel
            // 
            this.SidePanel.AutoScroll = true;
            this.SidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.SidePanel.Controls.Add(this.panel1);
            this.SidePanel.Controls.Add(this.NavPanel);
            this.SidePanel.Controls.Add(this.AdminSubPanel);
            this.SidePanel.Controls.Add(this.AdminBtn);
            this.SidePanel.Controls.Add(this.ViewSubPanel);
            this.SidePanel.Controls.Add(this.ViewBtn);
            this.SidePanel.Controls.Add(this.CreateOrderSubpanel);
            this.SidePanel.Controls.Add(this.AboutBtn);
            this.SidePanel.Controls.Add(this.CreateOrderBtn);
            this.SidePanel.Controls.Add(this.CreateEntitySubPanel);
            this.SidePanel.Controls.Add(this.CreateEntityBtn);
            this.SidePanel.Controls.Add(this.HomeBtn);
            this.SidePanel.Controls.Add(this.LogoPanel);
            this.SidePanel.Controls.Add(this.panel2);
            this.SidePanel.Controls.Add(this.panel4);
            this.SidePanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.SidePanel.Location = new System.Drawing.Point(0, 28);
            this.SidePanel.Name = "SidePanel";
            this.SidePanel.Size = new System.Drawing.Size(231, 833);
            this.SidePanel.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(22)))), ((int)(((byte)(38)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(3, 785);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(228, 2);
            this.panel1.TabIndex = 14;
            // 
            // CreateOrderSubpanel
            // 
            this.CreateOrderSubpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(42)))), ((int)(((byte)(61)))));
            this.CreateOrderSubpanel.Controls.Add(this.OpenSeparateBtn2);
            this.CreateOrderSubpanel.Controls.Add(this.CreateNewOrderBtn);
            this.CreateOrderSubpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.CreateOrderSubpanel.Location = new System.Drawing.Point(3, 416);
            this.CreateOrderSubpanel.Name = "CreateOrderSubpanel";
            this.CreateOrderSubpanel.Size = new System.Drawing.Size(228, 30);
            this.CreateOrderSubpanel.TabIndex = 13;
            // 
            // OpenSeparateBtn2
            // 
            this.OpenSeparateBtn2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("OpenSeparateBtn2.BackgroundImage")));
            this.OpenSeparateBtn2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.OpenSeparateBtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.OpenSeparateBtn2.FlatAppearance.BorderSize = 0;
            this.OpenSeparateBtn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OpenSeparateBtn2.Font = new System.Drawing.Font("Nirmala UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpenSeparateBtn2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.OpenSeparateBtn2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.OpenSeparateBtn2.ImageList = this.ImageList;
            this.OpenSeparateBtn2.Location = new System.Drawing.Point(194, 4);
            this.OpenSeparateBtn2.Name = "OpenSeparateBtn2";
            this.OpenSeparateBtn2.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.OpenSeparateBtn2.Size = new System.Drawing.Size(25, 20);
            this.OpenSeparateBtn2.TabIndex = 16;
            this.OpenSeparateBtn2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.OpenSeparateBtn2.UseVisualStyleBackColor = true;
            this.OpenSeparateBtn2.Click += new System.EventHandler(this.OpenSeparate2_Click);
            // 
            // CreateNewOrderBtn
            // 
            this.CreateNewOrderBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CreateNewOrderBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.CreateNewOrderBtn.FlatAppearance.BorderSize = 0;
            this.CreateNewOrderBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(82)))));
            this.CreateNewOrderBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CreateNewOrderBtn.Font = new System.Drawing.Font("Nirmala UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CreateNewOrderBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.CreateNewOrderBtn.Location = new System.Drawing.Point(0, 0);
            this.CreateNewOrderBtn.Name = "CreateNewOrderBtn";
            this.CreateNewOrderBtn.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.CreateNewOrderBtn.Size = new System.Drawing.Size(228, 29);
            this.CreateNewOrderBtn.TabIndex = 3;
            this.CreateNewOrderBtn.Text = "New Sales Order";
            this.CreateNewOrderBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreateNewOrderBtn.UseVisualStyleBackColor = true;
            this.CreateNewOrderBtn.Click += new System.EventHandler(this.CreateNewOrderBtn_Click);
            // 
            // AboutBtn
            // 
            this.AboutBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AboutBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.AboutBtn.FlatAppearance.BorderSize = 0;
            this.AboutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AboutBtn.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AboutBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.AboutBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AboutBtn.ImageIndex = 6;
            this.AboutBtn.ImageList = this.ImageList;
            this.AboutBtn.Location = new System.Drawing.Point(3, 787);
            this.AboutBtn.Name = "AboutBtn";
            this.AboutBtn.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.AboutBtn.Size = new System.Drawing.Size(228, 43);
            this.AboutBtn.TabIndex = 12;
            this.AboutBtn.Text = "        About TALOS";
            this.AboutBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AboutBtn.UseVisualStyleBackColor = true;
            this.AboutBtn.Click += new System.EventHandler(this.AboutBtn_Click);
            // 
            // HomeBtn
            // 
            this.HomeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.HomeBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.HomeBtn.FlatAppearance.BorderSize = 0;
            this.HomeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HomeBtn.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomeBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.HomeBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.HomeBtn.ImageIndex = 0;
            this.HomeBtn.ImageList = this.ImageList;
            this.HomeBtn.Location = new System.Drawing.Point(3, 197);
            this.HomeBtn.Name = "HomeBtn";
            this.HomeBtn.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.HomeBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.HomeBtn.Size = new System.Drawing.Size(228, 43);
            this.HomeBtn.TabIndex = 11;
            this.HomeBtn.Text = "        Home";
            this.HomeBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.HomeBtn.UseVisualStyleBackColor = true;
            this.HomeBtn.Click += new System.EventHandler(this.HomeBtn_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(22)))), ((int)(((byte)(38)))));
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(231, 28);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(3, 833);
            this.panel5.TabIndex = 0;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1234, 861);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.FooterPanel);
            this.Controls.Add(this.MainPanel);
            this.Controls.Add(this.SidePanel);
            this.Controls.Add(this.WidgetPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NewHome";
            this.WidgetPanel.ResumeLayout(false);
            this.WidgetPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.FooterPanel.ResumeLayout(false);
            this.FooterPanel.PerformLayout();
            this.LogoPanel.ResumeLayout(false);
            this.LogoPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.CreateEntitySubPanel.ResumeLayout(false);
            this.ViewSubPanel.ResumeLayout(false);
            this.AdminSubPanel.ResumeLayout(false);
            this.SidePanel.ResumeLayout(false);
            this.CreateOrderSubpanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Button MinimizeBtn;
        private System.Windows.Forms.Panel WidgetPanel;
        private System.Windows.Forms.Panel MainPanel;
        private System.Windows.Forms.Panel FooterPanel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel LogoPanel;
        private System.Windows.Forms.Label SecondaryTextLabel;
        private System.Windows.Forms.Label UsernameLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button CreateEntityBtn;
        private System.Windows.Forms.Panel CreateEntitySubPanel;
        private System.Windows.Forms.Button NewCustomerBtn;
        private System.Windows.Forms.Button CreateOrderBtn;
        private System.Windows.Forms.Button ViewBtn;
        private System.Windows.Forms.Panel ViewSubPanel;
        private System.Windows.Forms.Button ViewOrderBtn;
        private System.Windows.Forms.Button ViewCustomerBtn;
        private System.Windows.Forms.Button ViewStockBtn;
        private System.Windows.Forms.Button AdminBtn;
        private System.Windows.Forms.Panel AdminSubPanel;
        private System.Windows.Forms.Button ChangePasswordBtn;
        private System.Windows.Forms.Button CreateNewAdminBtn;
        private System.Windows.Forms.Panel NavPanel;
        private System.Windows.Forms.Panel SidePanel;
        private System.Windows.Forms.Button HomeBtn;
        private System.Windows.Forms.ImageList ImageList;
        private System.Windows.Forms.Button AboutBtn;
        private System.Windows.Forms.Panel Divider1;
        private System.Windows.Forms.Panel CreateOrderSubpanel;
        private System.Windows.Forms.Button CreateNewOrderBtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button OpenSeparateBtn1;
        private System.Windows.Forms.Button OpenSeparateBtn2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button OpenSeparateBtn3;
        private System.Windows.Forms.Button OpenSeparateBtn4;
        private System.Windows.Forms.Button OpenSeparateBtn5;
        private System.Windows.Forms.Button OpenSeparateBtn6;
        private System.Windows.Forms.Button NewEmployeeBtn;
        private System.Windows.Forms.Button NewSalespersonBtn;
        private System.Windows.Forms.Button OpenSeparateBtn7;
    }
}