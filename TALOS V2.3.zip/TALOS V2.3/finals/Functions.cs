﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace finals
{
    internal class Functions
    {
        public static string GetConnectionString()
        {
            //remember to drop constraint on sales.salesorderheader due date check
            //remember to fix the notes file path

            return "Data Source=NIKK\\SQLEXPRESS;Initial Catalog=AdventureWorks2019;Integrated Security=True; MultipleActiveResultSets=true";
            //return "Data Source =.\\MSSQLSERVER2019; Initial Catalog = AdventureWorks2019; User ID = sa; Password = pe3; MultipleActiveResultSets=true";
        }
    }
}
