﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace finals
{
    public partial class ProductCodeID : Form
    {
        System.Windows.Forms.TextBox ProductIDTextBox;
        DataTable dt;
        public ProductCodeID(System.Windows.Forms.TextBox ProductTextBox)
        {
            InitializeComponent();

            string sql = "select SpecialOfferProduct.ProductID as 'ProductID', name as 'Name', ProductNumber as 'Product Number', color as 'Color', ListPrice as 'Price', concat(size, SizeUnitMeasureCode) as 'Size', concat(weight,WeightUnitMeasureCode) as 'Weight', (select sum(Quantity) from Production.ProductInventory where Production.ProductInventory.ProductID = SpecialOfferProduct.ProductID) as 'Stock' from Production.Product join sales.SpecialOfferProduct on SpecialOfferProduct.ProductID = SpecialOfferProduct.ProductID join Production.ProductInventory on Production.Product.ProductID = SpecialOfferProduct.ProductID where (select sum(Quantity) from Production.ProductInventory where Production.ProductInventory.ProductID = SpecialOfferProduct.ProductID) is not null group by SpecialOfferProduct.ProductID,name,ProductNumber,color,listprice,Size,SizeUnitMeasureCode,Weight,WeightUnitMeasureCode";
            //string sql = "select SpecialOfferProduct.ProductID as 'ProductID', name as 'Name', ProductNumber as 'Product Number', color as 'Color', ListPrice as 'Price', concat(size, SizeUnitMeasureCode) as 'Size', concat(weight,WeightUnitMeasureCode) as 'Weight', (select sum(Quantity) from Production.ProductInventory where Production.ProductInventory.ProductID = SpecialOfferProduct.ProductID) as 'Stock' from Production.Product join sales.SpecialOfferProduct on SpecialOfferProduct.ProductID = SpecialOfferProduct.ProductID join Production.ProductInventory on Production.Product.ProductID = SpecialOfferProduct.ProductID where (select sum(Quantity) from Production.ProductInventory where Production.ProductInventory.ProductID = SpecialOfferProduct.productid) group by SpecialOfferProduct.ProductID,name,ProductNumber,color,listprice,Size,SizeUnitMeasureCode,Weight,WeightUnitMeasureCode";
            
            SqlConnection con;
            SqlCommand command;
            SqlDataAdapter da;
            con = new SqlConnection(Functions.GetConnectionString());
            con.Open();

            command = new SqlCommand(sql, con);
            da = new SqlDataAdapter(command);
            dt = new DataTable();
            da.Fill(dt);
            ProductGridView.DataSource = dt;

            ProductIDTextBox = ProductTextBox;

            //fix visuals of datagridview
            ProductGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
            ProductGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            ProductGridView.Columns[0].Width = 60;
            ProductGridView.Columns[1].Width = 165;
            ProductGridView.Columns[2].Width = 80;
            ProductGridView.Columns[3].Width = 65;
            ProductGridView.Columns[4].Width = 95;
            ProductGridView.Columns[5].Width = 65;
            ProductGridView.Columns[6].Width = 80;
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            SearchName();
        }
        private void SearchBoxCode_KeyDown(object sender, KeyEventArgs e)
        {
            SearchCode();
        }


        public void SearchName()
        {
            (ProductGridView.DataSource as DataTable).DefaultView.RowFilter = string.Format("Name LIKE '%{0}%'", SearchBox.Text);
        }

        public void SearchCode()
        {
            //(ProductGridView.DataSource as DataTable).DefaultView.RowFilter = string.Format("'ProductID' LIKE '{0}'", SearchBoxCode.Text);
            BindingSource bs_sp = new BindingSource();

            bs_sp.DataSource = ProductGridView.DataSource;
            bs_sp.Filter = "Convert(ProductID, 'System.String') like '" + SearchBoxCode.Text + "%'";
            ProductGridView.DataSource = bs_sp;
        }


        private void SearchBoxCode_Enter(object sender, EventArgs e)
        {
            SearchBox.Text = "";
            SearchCode();
        }

        private void SearchBox_Enter(object sender, EventArgs e)
        {
            SearchBoxCode.Text = "";
            SearchName();
        }

        private void ProductGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                ProductIDTextBox.Text = ProductGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                this.Dispose();
            }
            catch 
            {
                
            }
        }
    }
}
