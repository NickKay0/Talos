﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace finals
{
    public partial class StartScreen : Form
    {
        List<Label> notes = new List<Label>();
        List<Button> buttons = new List<Button>();

        int previousNoteY, previousNoteHeight;
        public StartScreen()
        {
            InitializeComponent();
            demoButton.Visible = false;

            try
            {
                DrawDataGridView();


                //fix visuals of datagridview
                QuickReorderGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
                QuickReorderGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                QuickReorderGridView.Columns[0].Width = 60;
                QuickReorderGridView.Columns[1].Width = 185;
                QuickReorderGridView.Columns[2].Width = 60;
                QuickReorderGridView.Columns[3].Width = 70;
                QuickReorderGridView.Columns[4].Width = 80;
                QuickReorderGridView.Columns[5].Width = 65;

                QuickReorderGridView.ScrollBars = ScrollBars.Vertical;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //read notes.txt file
            ReadTextFile();
        }

        private void ReorderSingularBtn_Click(object sender, EventArgs e)
        {
            string salesPersonID = SalespersonBox.Text;

            List<int> selectedCodes = new List<int>();

            List<int> tillSafetyLevelPerCode = new List<int>();
            List<ProductToReorder> reorders = new List<ProductToReorder>();
            string sql;
            try
            {
                SqlConnection con;
                SqlCommand command;
                SqlDataReader reader;
                con = new SqlConnection(Functions.GetConnectionString());
                con.Open();

                //verify spid
                if (!int.TryParse(salesPersonID, out int n) || string.IsNullOrEmpty(salesPersonID)) throw new CustomExceptionHandling.InvalidSPIDException();
                sql = $"select businessentityid from sales.salesperson where businessentityid = {salesPersonID}";
                command = new SqlCommand(sql, con);
                reader = command.ExecuteReader();
                if (!reader.HasRows) throw new CustomExceptionHandling.InvalidSPIDException();

                for(int i = 0; i < QuickReorderGridView.SelectedRows.Count; i++)
                {
                    selectedCodes.Add(Convert.ToInt32(QuickReorderGridView.SelectedRows[i].Cells[0].Value));
                }

                //reorder
                for (int i = 0; i < selectedCodes.Count; i++)
                {

                    sql = $"select SafetyStockLevel,sum(Quantity) from production.product join production.ProductInventory on Production.ProductInventory.ProductID = production.product.ProductID where product.productid = {selectedCodes[i]} group by safetystocklevel";
                    command = new SqlCommand(sql, con);
                    reader = command.ExecuteReader();
                    
                    if (reader.Read())
                    {
                        int amountTillSafetyLevel = reader.GetInt16(0) - reader.GetInt32(1);
                        int currentQuantity = reader.GetInt32(1);
                        tillSafetyLevelPerCode.Add(amountTillSafetyLevel);
                        sql = $"select LocationID from production.ProductInventory where ProductID = {selectedCodes[i]} order by quantity asc";
                        command = new SqlCommand(sql, con);
                        reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            sql = $"update production.ProductInventory set quantity = {amountTillSafetyLevel + currentQuantity} where locationid = {reader.GetInt16(0)} and productid = {selectedCodes[i]}";
                            command = new SqlCommand(sql, con);
                            command.CommandType = CommandType.Text;
                            command.ExecuteNonQuery();
                        }
                    }

                    //fill ProductToReorder.cs
                    sql = $"select top(1) AverageLeadTime,StandardPrice,purchasing.vendor.BusinessEntityID from purchasing.productvendor join purchasing.vendor on purchasing.vendor.BusinessEntityID = purchasing.ProductVendor.BusinessEntityID where purchasing.vendor.ActiveFlag = 1 and productid = {selectedCodes[i]} order by purchasing.Vendor.PreferredVendorStatus desc, standardprice asc";
                    command = new SqlCommand(sql, con);
                    reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        reorders.Add(new ProductToReorder(selectedCodes[i], tillSafetyLevelPerCode[i], reader.GetInt32(2), reader.GetInt32(0), double.Parse(reader.GetSqlMoney(1).ToString())));
                    }

                }

                int purchaseOrderId = 0;
                for (int i = 0; i < reorders.Count; i++)
                {
                    List<int> duplicateVendorsID = new List<int>();

                    if (duplicateVendorsID.Count == 0 || duplicateVendorsID.IndexOf(reorders[i].vendorId) == -1)
                    {
                        //do purchasing.purchaseorderheader stuff
                        duplicateVendorsID.Add(reorders[i].vendorId);
                        sql = $"insert into purchasing.purchaseorderheader (revisionnumber,status,employeeid,vendorid,shipmethodid,freight,orderdate,shipdate,modifieddate) values (default,default,(select businessentityid from humanresources.employee where businessentityid = {salesPersonID}),(select businessentityid from purchasing.vendor where businessentityid = {reorders[i].vendorId}),(select shipmethodid from purchasing.shipmethod where shipmethodid = 1),3.95,default,dateadd(day,{reorders[i].daysTillDelivery},GETDATE()),default)";
                        command = new SqlCommand(sql, con);
                        command.CommandType = CommandType.Text;
                        command.ExecuteNonQuery();

                        //get purchaseorderid
                        sql = $"select top(1) purchaseorderid from purchasing.purchaseorderheader order by purchaseorderid desc";
                        command = new SqlCommand(sql, con);
                        reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            purchaseOrderId = reader.GetInt32(0);
                        }
                    }

                    string unitPrice = reorders[i].standardPrice.ToString();
                    unitPrice = unitPrice.Replace(',', '.');
                    sql = $"insert into purchasing.PurchaseOrderDetail (PurchaseOrderID,DueDate,OrderQty,ProductID,UnitPrice,ReceivedQty,RejectedQty,ModifiedDate) values ((select PurchaseOrderID from Purchasing.PurchaseOrderHeader where purchaseorderid = {purchaseOrderId}),dateadd(day,{reorders[i].daysTillDelivery},GETDATE()),{reorders[i].amountTillSafetyLevel},{reorders[i].code},{unitPrice},{reorders[i].amountTillSafetyLevel},0,default)";
                    command = new SqlCommand(sql, con);
                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();
                }

                DrawDataGridView();
                MessageBox.Show("The Codes Succesfully Reordered.", "Success");
                
                con.Close();
            }
            catch (CustomExceptionHandling.InvalidSPIDException)
            {
                MessageBox.Show("Invalid Salesperson ID.", "Warning");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void ReorderAllBtn_Click(object sender, EventArgs e)
        {
            string salesPersonID = SalespersonBox.Text;

            List<int> selectedCodes = new List<int>();

            List<int> tillSafetyLevelPerCode = new List<int>();
            List<ProductToReorder> reorders = new List<ProductToReorder>();
            string sql;
            try
            {
                SqlConnection con;
                SqlCommand command;
                SqlDataReader reader;
                con = new SqlConnection(Functions.GetConnectionString());
                con.Open();

                //verify spid
                if (!int.TryParse(salesPersonID, out int n) || string.IsNullOrEmpty(salesPersonID)) throw new CustomExceptionHandling.InvalidSPIDException();
                sql = $"select businessentityid from sales.salesperson where businessentityid = {salesPersonID}";
                command = new SqlCommand(sql, con);
                reader = command.ExecuteReader();
                if (!reader.HasRows) throw new CustomExceptionHandling.InvalidSPIDException();

                sql = "select product.productid from production.Product join production.ProductInventory on production.ProductInventory.ProductID = production.Product.ProductID group by product.productid, ReorderPoint having ReorderPoint - sum(Quantity) > 0 and sum(Quantity) > -1";
                command = new SqlCommand(sql, con);
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    selectedCodes.Add(reader.GetInt32(0));
                }


                //reorder
                for (int i = 0; i < selectedCodes.Count; i++)
                {
                    sql = $"select SafetyStockLevel,sum(Quantity) from production.product join production.ProductInventory on Production.ProductInventory.ProductID = production.product.ProductID where product.productid = {selectedCodes[i]} group by safetystocklevel";
                    command = new SqlCommand(sql, con);
                    reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        int amountTillSafetyLevel = reader.GetInt16(0) - reader.GetInt32(1);
                        tillSafetyLevelPerCode.Add(amountTillSafetyLevel);
                        int currentQuantity = reader.GetInt32(1);
                        sql = $"select LocationID from production.ProductInventory where ProductID = {selectedCodes[i]} order by quantity asc";
                        command = new SqlCommand(sql, con);
                        reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            sql = $"update production.ProductInventory set quantity = {amountTillSafetyLevel + currentQuantity} where locationid = {reader.GetInt16(0)} and productid = {selectedCodes[i]}";
                            command = new SqlCommand(sql, con);
                            command.CommandType = CommandType.Text;
                            command.ExecuteNonQuery();
                        }
                    }

                    //fill ProductToReorder.cs
                    sql = $"select top(1) AverageLeadTime,StandardPrice,purchasing.vendor.BusinessEntityID from purchasing.productvendor join purchasing.vendor on purchasing.vendor.BusinessEntityID = purchasing.ProductVendor.BusinessEntityID where purchasing.vendor.ActiveFlag = 1 and productid = {selectedCodes[i]} order by purchasing.Vendor.PreferredVendorStatus desc, standardprice asc";
                    command = new SqlCommand(sql, con);
                    reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        reorders.Add(new ProductToReorder(selectedCodes[i], tillSafetyLevelPerCode[i], reader.GetInt32(2), reader.GetInt32(0), double.Parse(reader.GetSqlMoney(1).ToString())));
                    }

                }

                int purchaseOrderId = 0;
                for (int i = 0; i < reorders.Count; i++)
                {
                    List<int> duplicateVendorsID = new List<int>();

                    if (duplicateVendorsID.Count == 0 || duplicateVendorsID.IndexOf(reorders[i].vendorId) == -1)
                    {
                        //do purchasing.purchaseorderheader stuff
                        duplicateVendorsID.Add(reorders[i].vendorId);
                        sql = $"insert into purchasing.purchaseorderheader (revisionnumber,status,employeeid,vendorid,shipmethodid,freight,orderdate,shipdate,modifieddate) values (default,default,(select businessentityid from humanresources.employee where businessentityid = {salesPersonID}),(select businessentityid from purchasing.vendor where businessentityid = {reorders[i].vendorId}),(select shipmethodid from purchasing.shipmethod where shipmethodid = 1),3.95,default,dateadd(day,{reorders[i].daysTillDelivery},GETDATE()),default)";
                        command = new SqlCommand(sql, con);
                        command.CommandType = CommandType.Text;
                        command.ExecuteNonQuery();

                        //get purchaseorderid
                        sql = $"select top(1) purchaseorderid from purchasing.purchaseorderheader order by purchaseorderid desc";
                        command = new SqlCommand(sql, con);
                        reader = command.ExecuteReader();
                        if (reader.Read())
                        {
                            purchaseOrderId = reader.GetInt32(0);
                        }
                    }

                    string unitPrice = reorders[i].standardPrice.ToString();
                    unitPrice = unitPrice.Replace(',', '.');
                    sql = $"insert into purchasing.PurchaseOrderDetail (PurchaseOrderID,DueDate,OrderQty,ProductID,UnitPrice,ReceivedQty,RejectedQty,ModifiedDate) values ((select PurchaseOrderID from Purchasing.PurchaseOrderHeader where purchaseorderid = {purchaseOrderId}),dateadd(day,{reorders[i].daysTillDelivery},GETDATE()),{reorders[i].amountTillSafetyLevel},{reorders[i].code},{unitPrice},{reorders[i].amountTillSafetyLevel},0,default)";
                    command = new SqlCommand(sql, con);
                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();
                }

                DrawDataGridView();
                MessageBox.Show("The Codes Succesfully Reordered.", "Success");

                con.Close();
            }
            catch (CustomExceptionHandling.InvalidSPIDException)
            {
                MessageBox.Show("Invalid Salesperson ID.", "Warning");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        void DrawDataGridView()
        {
            QuickReorderGridView.Refresh();

            string sql = "select product.productid as 'Code',name as 'Name',sum(Quantity) as 'Stock',ReorderPoint as 'Reorder Point',SafetyStockLevel as 'Safety Stock',(ReorderPoint - sum(Quantity)) as 'Stock Diff' from production.Product join production.ProductInventory on production.ProductInventory.ProductID = production.Product.ProductID group by product.productid,name,SafetyStockLevel,ReorderPoint having ReorderPoint - sum(Quantity) > 0 and sum(Quantity) > -1";

            SqlConnection con;
            SqlCommand command;
            SqlDataAdapter da;
            con = new SqlConnection(Functions.GetConnectionString());
            con.Open();

            DataTable dt = new DataTable();
            command = new SqlCommand(sql, con);
            da = new SqlDataAdapter(command);
            dt = new DataTable();
            da.Fill(dt);

            QuickReorderGridView.DataSource = dt;

            if(QuickReorderGridView.Rows.Count == 0 )
            {
                QuickReorderGridView.Visible = false;
            }
            con.Close();
        }

        private void AddToNotes_Click(object sender, EventArgs e)
        {
            if(NoteWriteBox.Text.Length > 0)
            {
                if(!IsTextFileEmpty("C:\\Users\\PE3.PE3-01\\Desktop\\Talos\\TALOS V2.3\\finals\\Notes.txt"))
                {
                    using (StreamWriter writer = File.AppendText("C:\\Users\\PE3.PE3-01\\Desktop\\Talos\\TALOS V2.3\\finals\\Notes.txt"))
                    {
                        writer.Write("\n" + NoteWriteBox.Text);
                        writer.Close();
                    }
                }
                else
                {
                    using (StreamWriter writer = File.AppendText("C:\\Users\\PE3.PE3-01\\Desktop\\Talos\\TALOS V2.3\\finals\\Notes.txt"))
                    {
                        writer.Write(NoteWriteBox.Text);
                        writer.Close();
                    }
                }
                
                AddNote();
            }
        }

        void AddNote()
        {
            //button
            Button button = new Button();
            button.Name = "NoteButton_"+buttons.Count;
            button.Click += new EventHandler(NoteButton_Click);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackgroundImage = demoButton.BackgroundImage;
            button.BackgroundImageLayout = demoButton.BackgroundImageLayout;
            button.Cursor = Cursors.Hand;
            button.Width = 15;
            button.Height = 15;
            NotePanel.Controls.Add(button);  
            buttons.Add(button);

            //label
            Label note = new Label();
            note.Name = "NoteLabel_" + notes.Count;
            note.Text = NoteWriteBox.Text;
            note.Width = 345;
            if (note.Text.Length <= 52)
            {
                note.Height = 20;
            }
            else if (note.Text.Length <= 104)
            {
                note.Height = 40;
            }
            else note.Height = 60;
            NotePanel.Controls.Add(note);

            if(notes.Count == 0)
            {
                note.Location = new Point(30, 0);
            }else
            {
                note.Location = new Point(30, previousNoteY + previousNoteHeight + note.Height + 5);
            }
            previousNoteY = note.Location.Y;
            previousNoteHeight = note.Height;
            notes.Add(note);

            button.Left = note.Left - 20;
            button.Top = note.Top + 2;

            NoteWriteBox.Text = "";
        }

        private void NoteButton_Click(object sender,EventArgs e)
        {
            Button btn = (Button)sender;
            
            //get index
            string[] splittedName = new string[2];
            splittedName = btn.Name.Split('_');
            int noteIndex = int.Parse(splittedName[1]);

            int removedHeight = notes[noteIndex].Height;
            notes[noteIndex].Dispose();
            btn.Dispose();

            for(int i = noteIndex; i < notes.Count-1; i++)
            {
                notes[i + 1].Location = new Point(30, notes[i + 1].Location.Y - notes[i + 1].Height - removedHeight - 5);
                notes[i + 1].Name = "NoteLabel_" + i;

                buttons[i+1].Left = notes[i+1].Left - 20;
                buttons[i + 1].Top = notes[i + 1].Top + 2;
                buttons[i + 1].Name = "NoteButton_"+i;
            }
            previousNoteY = notes[notes.Count - 1].Location.Y;
            previousNoteHeight = notes[notes.Count-1].Height;

            notes.RemoveAt(noteIndex);
            notes.TrimExcess();
            buttons.RemoveAt(noteIndex);
            buttons.TrimExcess();

            string remainingNotes = "";
            for (int i = 0; i < notes.Count; i++)
            {
                if (i != notes.Count - 1)
                {
                    remainingNotes += notes[i].Text + "\n";
                }
                else
                {
                    remainingNotes += notes[i].Text;
                }
            }

            WriteToTextFile(remainingNotes);
        }

        public bool IsTextFileEmpty(string fileName)
        {
            var info = new FileInfo(fileName);
            if (info.Length < 6)
            {
                var content = File.ReadAllText(fileName);
                return content.Length == 0;
            }
            return false;
        }

        void ReadTextFile()
        {
            string line;
            try
            {
                if (!IsTextFileEmpty("C:\\Users\\PE3.PE3-01\\Desktop\\Talos\\TALOS V2.3\\finals\\Notes.txt"))
                {
                    StreamReader sr = new StreamReader("C:\\Users\\PE3.PE3-01\\Desktop\\Talos\\TALOS V2.3\\finals\\Notes.txt");
                    line = sr.ReadLine();
                    while (line != null)
                    {
                        NoteWriteBox.Text = line;
                        AddNote();
                        line = sr.ReadLine();
                    }
                    sr.Close();
                }
                else
                {
                    
                }
            }catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void NoteWriteBox_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                if(NoteWriteBox.Text.Length>0) AddToNotes_Click(null, null);
            }
        }

        void WriteToTextFile(string text)
        {
            using (StreamWriter writer = new StreamWriter("C:\\Users\\PE3.PE3-01\\Desktop\\Talos\\TALOS V2.3\\finals\\Notes.txt"))
            {
                writer.Write(text);
                writer.Close();
            }
        }
    }
}
