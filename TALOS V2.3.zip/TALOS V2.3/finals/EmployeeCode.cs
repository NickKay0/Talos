﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finals
{
    public partial class EmployeeCode : Form
    {
        TextBox textbox;
        public EmployeeCode(TextBox tb)
        {
            InitializeComponent();

            SqlConnection con = new SqlConnection(Functions.GetConnectionString());
            SqlCommand command;
            SqlDataAdapter da;
            con.Open();

            string sql = "select employee.BusinessEntityID as 'ID',concat(FirstName, ' ',LastName) as 'Name',JobTitle as 'Job Title',EmailAddress as 'Email',PhoneNumber as 'Phone' from HumanResources.Employee join person.Person on person.BusinessEntityID = Employee.BusinessEntityID left join person.EmailAddress on EmailAddress.BusinessEntityID = Employee.BusinessEntityID join person.PersonPhone on PersonPhone.BusinessEntityID = Employee.BusinessEntityID order by humanresources.employee.modifieddate desc";
            command = new SqlCommand(sql, con);
            da = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);
            EmployeeGridView.DataSource = dt;

            EmployeeGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
            EmployeeGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            EmployeeGridView.Columns[0].Width = 60;
            EmployeeGridView.Columns[1].Width = 150;
            EmployeeGridView.Columns[2].Width = 250;
            EmployeeGridView.Columns[3].Width = 250;
            EmployeeGridView.Columns[4].Width = 150;

            textbox = tb;
        }

        public void SearchName()
        {
            (EmployeeGridView.DataSource as DataTable).DefaultView.RowFilter = string.Format("Name LIKE '%{0}%'", SearchBox.Text);
        }

        public void SearchCode()
        {
            BindingSource bs_sp = new BindingSource();

            bs_sp.DataSource = EmployeeGridView.DataSource;
            bs_sp.Filter = "Convert(ID, 'System.String') like '" + SearchBoxCode.Text + "%'";
            EmployeeGridView.DataSource = bs_sp;
        }

        private void EmployeeGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                textbox.Text = EmployeeGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                this.Dispose();
            }
            catch
            {

            }
        }

        private void SearchBox_TextChanged(object sender, EventArgs e)
        {
            SearchBoxCode.Text = "";
            SearchName();
        }

        private void SearchBoxCode_TextChanged(object sender, EventArgs e)
        {
            SearchBox.Text = "";
            SearchCode();
        }
    }
}
