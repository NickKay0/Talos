﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;

namespace finals
{
    public partial class Home : Form
    {
        //bool darkModeActive;

        //Colors
        //Dark theme color: 46, 51, 73
        //Button Hilight Color: 48; 56; 82
        //Hilight color: 0, 156, 255
        //button select hilight: 48, 56, 82
        string username = "";

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,
            int nTopRect,
            int nRightRect,
            int nBottomRect,
            int nWidthEllipse,
            int nHeightEllipse
        );

        public Home(string user)
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 22, 22));

            HideMenus();
            NavPanel.Visible = false;

            //start screen
            HomeBtn_Click(null, null);
            this.username = char.ToUpper(user[0]) + user.Substring(1);
            UsernameLabel.Text = username;
            SecondaryTextLabel.Text = $"Welcome Home, {username}";
        }

        private void HomeBtn_Click(object sender, EventArgs e)
        {
            NavPanel.Height = HomeBtn.Height;
            NavPanel.Top = HomeBtn.Top;
            NavPanel.Left = HomeBtn.Left;
            if (!NavPanel.Visible) NavPanel.Visible = true;

            StartScreen sc = new StartScreen();
            sc.TopLevel = false;
            sc.AutoScroll = true;
            MainPanel.Controls.Clear();
            MainPanel.Controls.Add(sc);
            sc.Size = MainPanel.Size;

            sc.Show();
        }

        private void CreateEntityBtn_Click(object sender, EventArgs e)
        {
            ShowSubMenu(CreateEntitySubPanel);
            NavPanel.Height = CreateEntityBtn.Height;
            NavPanel.Top = CreateEntityBtn.Top;
            NavPanel.Left = CreateEntityBtn.Left;
            if (!NavPanel.Visible) NavPanel.Visible = true;
        }

        private void ViewBtn_Click(object sender, EventArgs e)
        {
            ShowSubMenu(ViewSubPanel);
            NavPanel.Height = ViewBtn.Height;
            NavPanel.Top = ViewBtn.Top;
            NavPanel.Left = ViewBtn.Left;
            if (!NavPanel.Visible) NavPanel.Visible = true;
        }

        private void AdminBtn_Click(object sender, EventArgs e)
        {
            ShowSubMenu(AdminSubPanel);
            NavPanel.Height = AdminBtn.Height;
            NavPanel.Top = AdminBtn.Top;
            NavPanel.Left = AdminBtn.Left;
            if (!NavPanel.Visible) NavPanel.Visible = true;
        }

        private void CreateNewOrderBtn_Click(object sender, EventArgs e)
        {
            NavPanel.Height = CreateOrderBtn.Height;
            NavPanel.Top = CreateOrderBtn.Top;
            NavPanel.Left = CreateOrderBtn.Left;
            if (!NavPanel.Visible) NavPanel.Visible = true;

            ResetSeparateButtons();
            OpenSeparateBtn2.BackColor = Color.FromArgb(48, 56, 82);

            CreateNewOrder cno = new CreateNewOrder();
            cno.TopLevel = false;
            cno.AutoScroll = true;
            MainPanel.Controls.Clear();
            MainPanel.Controls.Add(cno);
            cno.Show();

            HilightButton(CreateNewOrderBtn);
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Logout l = new Logout(this); 
            l.Show();
        }

        private void MinimizeBtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }


        private void NewCustomerBtn_Click(object sender, EventArgs e)
        {
            NewCustomer nc = new NewCustomer();
            nc.TopLevel = false;
            nc.AutoScroll = true;
            MainPanel.Controls.Clear();
            MainPanel.Controls.Add(nc);
            nc.Size = MainPanel.Size;

            ResetSeparateButtons();
            OpenSeparateBtn1.BackColor = Color.FromArgb(48, 56, 82);

            nc.Show();
            HilightButton(NewCustomerBtn);
        }

        private void NewSalespersonBtn_Click(object sender, EventArgs e)
        {
            NewEmployee np = new NewEmployee();
            np.TopLevel = false;
            np.AutoScroll = true;
            MainPanel.Controls.Clear();
            MainPanel.Controls.Add(np);
            np.Size = MainPanel.Size;

            ResetSeparateButtons();
            OpenSeparateBtn6.BackColor = Color.FromArgb(48, 56, 82);

            np.Show();

            HilightButton(NewEmployeeBtn);
        }

        private void NewEmployeeBtn_Click(object sender, EventArgs e)
        {
            NewSalesperson ns = new NewSalesperson();
            ns.TopLevel = false;
            ns.AutoScroll = true;
            MainPanel.Controls.Clear();
            MainPanel.Controls.Add(ns);
            ns.Size = MainPanel.Size;

            ResetSeparateButtons();
            OpenSeparateBtn7.BackColor = Color.FromArgb(48, 56, 82);

            ns.Show();

            HilightButton(NewSalespersonBtn);
        }

        private void ViewStockBtn_Click(object sender, EventArgs e)
        {
            Stock st = new Stock();
            st.TopLevel = false;
            st.AutoScroll = true;
            MainPanel.Controls.Clear();
            MainPanel.Controls.Add(st);
            st.Size = MainPanel.Size;

            ResetSeparateButtons();
            OpenSeparateBtn3.BackColor = Color.FromArgb(48, 56, 82);

            st.Show();
            HilightButton(ViewStockBtn);
        }

        private void ViewCustomerBtn_Click(object sender, EventArgs e)
        {
            ViewEntity ve = new ViewEntity();
            ve.TopLevel = false;
            ve.AutoScroll = true;
            MainPanel.Controls.Clear();
            MainPanel.Controls.Add(ve);
            ve.Size = MainPanel.Size;

            ResetSeparateButtons();
            OpenSeparateBtn3.BackColor = Color.FromArgb(48, 56, 82);

            ve.Show();
            HilightButton(ViewCustomerBtn);
        }

        private void ViewOrderBtn_Click(object sender, EventArgs e)
        {
            ViewOrder vo = new ViewOrder();
            vo.TopLevel = false;
            vo.AutoScroll = true;
            MainPanel.Controls.Clear();
            MainPanel.Controls.Add(vo);
            vo.Size = MainPanel.Size;

            vo.Show();
            HilightButton(ViewOrderBtn);
        }

        private void CreateNewAdminBtn_Click(object sender, EventArgs e)
        {
            NewAdmin na = new NewAdmin();
            na.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            na.Show();
            HilightButton(CreateNewAdminBtn);
        }

        private void ChangePasswordBtn_Click(object sender, EventArgs e)
        {
            ChangePassword cp = new ChangePassword(username);
            cp.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            cp.Show();
            HilightButton(ChangePasswordBtn);
        }




        void HilightButton(Button btn)
        {
                ResetButtonHilight();
                btn.BackColor = Color.FromArgb(48, 56, 82);
        }

        void ResetButtonHilight()
        {
            NewCustomerBtn.BackColor = Color.FromArgb(36, 42, 61);
            NewEmployeeBtn.BackColor = Color.FromArgb(36, 42, 61);
            NewSalespersonBtn.BackColor = Color.FromArgb(36, 42, 61);

            CreateNewOrderBtn.BackColor = Color.FromArgb(36, 42, 61);

            ViewStockBtn.BackColor = Color.FromArgb(36, 42, 61);
            ViewCustomerBtn.BackColor = Color.FromArgb(36, 42, 61);
            ViewOrderBtn.BackColor = Color.FromArgb(36, 42, 61);

            CreateNewAdminBtn.BackColor = Color.FromArgb(36, 42, 61);
            ChangePasswordBtn.BackColor = Color.FromArgb(36, 42, 61);
        }

        void HideMenus()
        {
            CreateEntitySubPanel.Visible = false;
            ViewSubPanel.Visible = false;
            AdminSubPanel.Visible = false;
            CreateOrderSubpanel.Visible = false;
        }

        void ShowSubMenu(Panel subMenu)
        {
            if (subMenu.Visible)
            {
                subMenu.Visible = false;
            }
            else
            {
                subMenu.Visible = true;
            }
        }

        private void CreateOrderBtn_Click(object sender, EventArgs e)
        {
            ShowSubMenu(CreateOrderSubpanel);
            NavPanel.Height = CreateOrderBtn.Height;
            NavPanel.Top = CreateOrderBtn.Top;
            NavPanel.Left = CreateOrderBtn.Left;
            if (!NavPanel.Visible) NavPanel.Visible = true;
        }

        private void OpenSeparateBtn1_Click(object sender, EventArgs e)
        {
            NewCustomer nc = new NewCustomer();
            nc.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            nc.Show();
        }

        private void OpenSeparate2_Click(object sender, EventArgs e)
        {
            CreateNewOrder cno = new CreateNewOrder();
            cno.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            cno.Show();
        }

        private void ResetSeparateButtons()
        {
            OpenSeparateBtn1.BackColor = Color.FromArgb(36, 42, 61);
            OpenSeparateBtn2.BackColor = Color.FromArgb(36, 42, 61);
            OpenSeparateBtn3.BackColor = Color.FromArgb(36, 42, 61);
            OpenSeparateBtn4.BackColor = Color.FromArgb(36, 42, 61);
            OpenSeparateBtn5.BackColor = Color.FromArgb(36, 42, 61);
            OpenSeparateBtn6.BackColor = Color.FromArgb(36, 42, 61);
            OpenSeparateBtn7.BackColor = Color.FromArgb(36, 42, 61);
        }


        //drag around window
        private bool dragging = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            dragCursorPoint = Cursor.Position;
            dragFormPoint = this.Location;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(dif));
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void OpenSeparateBtn3_Click(object sender, EventArgs e)
        {
            Stock st = new Stock();
            st.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            st.Show();
        }

        private void OpenSeparate4_Click(object sender, EventArgs e)
        {
            ViewEntity ve = new ViewEntity();
            ve.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            ve.Show();

            ResetSeparateButtons();
            OpenSeparateBtn4.BackColor = Color.FromArgb(48, 56, 82);
        }

        private void OpenSeparateBtn5_Click(object sender, EventArgs e)
        {
            ViewOrder vo = new ViewOrder();
            vo.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            vo.Show();

            ResetSeparateButtons();
            OpenSeparateBtn5.BackColor = Color.FromArgb(48, 56, 82);
        }

        private void OpenSeparateBtn6_Click(object sender, EventArgs e)
        {
            NewEmployee ns = new NewEmployee();
            ns.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            ns.Show();

            ResetSeparateButtons();
            OpenSeparateBtn6.BackColor = Color.FromArgb(48, 56, 82);
        }

        private void OpenSeparateBtn7_Click(object sender, EventArgs e)
        {
            NewSalesperson ns = new NewSalesperson();
            ns.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            ns.Show();

            ResetSeparateButtons();
            OpenSeparateBtn7.BackColor = Color.FromArgb(48, 56, 82);
        }

        private void AboutBtn_Click(object sender, EventArgs e)
        {
            AboutPage ap = new AboutPage();
            ap.TopLevel = false;
            ap.AutoScroll = true;
            MainPanel.Controls.Clear();
            MainPanel.Controls.Add(ap);
            ap.Size = MainPanel.Size;

            ap.Show();
        }
    }
}