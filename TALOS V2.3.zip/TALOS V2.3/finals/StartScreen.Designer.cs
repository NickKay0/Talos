﻿namespace finals
{
    partial class StartScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StartScreen));
            this.panel2 = new System.Windows.Forms.Panel();
            this.ShadowPanel4 = new System.Windows.Forms.Panel();
            this.SalespersonBox = new System.Windows.Forms.TextBox();
            this.ShadowPanel3 = new System.Windows.Forms.Panel();
            this.ReorderAll = new System.Windows.Forms.Button();
            this.ShadowPanel2 = new System.Windows.Forms.Panel();
            this.ReorderSingular = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.QuickReorderGridView = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.ShadowPanel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.demoButton = new System.Windows.Forms.Button();
            this.NotePanel = new System.Windows.Forms.Panel();
            this.NoteWriteBox = new System.Windows.Forms.RichTextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.AddToNotes = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.ShadowPanel4.SuspendLayout();
            this.ShadowPanel3.SuspendLayout();
            this.ShadowPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.QuickReorderGridView)).BeginInit();
            this.ShadowPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.ShadowPanel4);
            this.panel2.Controls.Add(this.ShadowPanel3);
            this.panel2.Controls.Add(this.ShadowPanel2);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.QuickReorderGridView);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(562, 504);
            this.panel2.TabIndex = 3;
            // 
            // ShadowPanel4
            // 
            this.ShadowPanel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.ShadowPanel4.Controls.Add(this.SalespersonBox);
            this.ShadowPanel4.Location = new System.Drawing.Point(25, 382);
            this.ShadowPanel4.Name = "ShadowPanel4";
            this.ShadowPanel4.Size = new System.Drawing.Size(74, 24);
            this.ShadowPanel4.TabIndex = 66;
            // 
            // SalespersonBox
            // 
            this.SalespersonBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.SalespersonBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SalespersonBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.SalespersonBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.SalespersonBox.Location = new System.Drawing.Point(0, 0);
            this.SalespersonBox.Name = "SalespersonBox";
            this.SalespersonBox.Size = new System.Drawing.Size(72, 22);
            this.SalespersonBox.TabIndex = 61;
            // 
            // ShadowPanel3
            // 
            this.ShadowPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.ShadowPanel3.Controls.Add(this.ReorderAll);
            this.ShadowPanel3.Location = new System.Drawing.Point(373, 435);
            this.ShadowPanel3.Name = "ShadowPanel3";
            this.ShadowPanel3.Size = new System.Drawing.Size(175, 43);
            this.ShadowPanel3.TabIndex = 65;
            // 
            // ReorderAll
            // 
            this.ReorderAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.ReorderAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ReorderAll.FlatAppearance.BorderSize = 0;
            this.ReorderAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReorderAll.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.ReorderAll.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.ReorderAll.Location = new System.Drawing.Point(0, 0);
            this.ReorderAll.Name = "ReorderAll";
            this.ReorderAll.Size = new System.Drawing.Size(172, 40);
            this.ReorderAll.TabIndex = 57;
            this.ReorderAll.Text = "Reorder All";
            this.ReorderAll.UseVisualStyleBackColor = false;
            this.ReorderAll.Click += new System.EventHandler(this.ReorderAllBtn_Click);
            // 
            // ShadowPanel2
            // 
            this.ShadowPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.ShadowPanel2.Controls.Add(this.ReorderSingular);
            this.ShadowPanel2.Location = new System.Drawing.Point(25, 435);
            this.ShadowPanel2.Name = "ShadowPanel2";
            this.ShadowPanel2.Size = new System.Drawing.Size(175, 43);
            this.ShadowPanel2.TabIndex = 64;
            // 
            // ReorderSingular
            // 
            this.ReorderSingular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.ReorderSingular.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ReorderSingular.FlatAppearance.BorderSize = 0;
            this.ReorderSingular.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReorderSingular.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.ReorderSingular.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.ReorderSingular.Location = new System.Drawing.Point(0, 0);
            this.ReorderSingular.Name = "ReorderSingular";
            this.ReorderSingular.Size = new System.Drawing.Size(172, 40);
            this.ReorderSingular.TabIndex = 56;
            this.ReorderSingular.Text = "Reorder Selected";
            this.ReorderSingular.UseVisualStyleBackColor = false;
            this.ReorderSingular.Click += new System.EventHandler(this.ReorderSingularBtn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label5.ForeColor = System.Drawing.Color.Gainsboro;
            this.label5.Location = new System.Drawing.Point(120, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(335, 20);
            this.label5.TabIndex = 63;
            this.label5.Text = "All Codes Bellow The Reorder Point Show Here";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.label6.Location = new System.Drawing.Point(205, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(140, 25);
            this.label6.TabIndex = 62;
            this.label6.Text = "Quick Reorder";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(20, 354);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(148, 25);
            this.label8.TabIndex = 60;
            this.label8.Text = "Salesperson ID:";
            // 
            // QuickReorderGridView
            // 
            this.QuickReorderGridView.AllowUserToAddRows = false;
            this.QuickReorderGridView.AllowUserToDeleteRows = false;
            this.QuickReorderGridView.AllowUserToResizeRows = false;
            this.QuickReorderGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(78)))), ((int)(((byte)(110)))));
            this.QuickReorderGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.QuickReorderGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.QuickReorderGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.QuickReorderGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.QuickReorderGridView.DefaultCellStyle = dataGridViewCellStyle10;
            this.QuickReorderGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.QuickReorderGridView.Location = new System.Drawing.Point(16, 84);
            this.QuickReorderGridView.Name = "QuickReorderGridView";
            this.QuickReorderGridView.ReadOnly = true;
            this.QuickReorderGridView.RowHeadersVisible = false;
            this.QuickReorderGridView.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.QuickReorderGridView.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.QuickReorderGridView.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(78)))), ((int)(((byte)(110)))));
            this.QuickReorderGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.QuickReorderGridView.ShowCellErrors = false;
            this.QuickReorderGridView.Size = new System.Drawing.Size(532, 245);
            this.QuickReorderGridView.TabIndex = 55;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(136, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(297, 20);
            this.label3.TabIndex = 67;
            this.label3.Text = "No Product Is Below The Reorder Point :)";
            // 
            // ShadowPanel1
            // 
            this.ShadowPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.ShadowPanel1.Controls.Add(this.panel2);
            this.ShadowPanel1.Location = new System.Drawing.Point(12, 12);
            this.ShadowPanel1.Name = "ShadowPanel1";
            this.ShadowPanel1.Size = new System.Drawing.Size(570, 510);
            this.ShadowPanel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(162, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "To-Do:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel15);
            this.panel1.Controls.Add(this.demoButton);
            this.panel1.Controls.Add(this.NotePanel);
            this.panel1.Controls.Add(this.NoteWriteBox);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(376, 504);
            this.panel1.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel5.Location = new System.Drawing.Point(47, 377);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(300, 2);
            this.panel5.TabIndex = 77;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel15.Location = new System.Drawing.Point(47, 39);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(300, 2);
            this.panel15.TabIndex = 76;
            // 
            // demoButton
            // 
            this.demoButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("demoButton.BackgroundImage")));
            this.demoButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.demoButton.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.demoButton.FlatAppearance.BorderSize = 0;
            this.demoButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.demoButton.Location = new System.Drawing.Point(19, 458);
            this.demoButton.Name = "demoButton";
            this.demoButton.Size = new System.Drawing.Size(20, 20);
            this.demoButton.TabIndex = 0;
            this.demoButton.UseVisualStyleBackColor = true;
            // 
            // NotePanel
            // 
            this.NotePanel.AutoScroll = true;
            this.NotePanel.Font = new System.Drawing.Font("Segoe UI", 10.25F, System.Drawing.FontStyle.Bold);
            this.NotePanel.ForeColor = System.Drawing.Color.White;
            this.NotePanel.Location = new System.Drawing.Point(0, 45);
            this.NotePanel.Name = "NotePanel";
            this.NotePanel.Size = new System.Drawing.Size(376, 331);
            this.NotePanel.TabIndex = 68;
            // 
            // NoteWriteBox
            // 
            this.NoteWriteBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.NoteWriteBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NoteWriteBox.Font = new System.Drawing.Font("Segoe UI", 10.25F, System.Drawing.FontStyle.Bold);
            this.NoteWriteBox.ForeColor = System.Drawing.Color.White;
            this.NoteWriteBox.Location = new System.Drawing.Point(32, 391);
            this.NoteWriteBox.MaxLength = 150;
            this.NoteWriteBox.Multiline = false;
            this.NoteWriteBox.Name = "NoteWriteBox";
            this.NoteWriteBox.Size = new System.Drawing.Size(322, 47);
            this.NoteWriteBox.TabIndex = 67;
            this.NoteWriteBox.Text = "";
            this.NoteWriteBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.NoteWriteBox_KeyDown);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel3.Controls.Add(this.AddToNotes);
            this.panel3.Location = new System.Drawing.Point(104, 444);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(175, 43);
            this.panel3.TabIndex = 66;
            // 
            // AddToNotes
            // 
            this.AddToNotes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.AddToNotes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddToNotes.FlatAppearance.BorderSize = 0;
            this.AddToNotes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddToNotes.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.AddToNotes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.AddToNotes.Location = new System.Drawing.Point(0, 0);
            this.AddToNotes.Name = "AddToNotes";
            this.AddToNotes.Size = new System.Drawing.Size(172, 40);
            this.AddToNotes.TabIndex = 57;
            this.AddToNotes.Text = "Add To Notes";
            this.AddToNotes.UseVisualStyleBackColor = false;
            this.AddToNotes.Click += new System.EventHandler(this.AddToNotes_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel4.Controls.Add(this.panel1);
            this.panel4.Location = new System.Drawing.Point(601, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(384, 510);
            this.panel4.TabIndex = 5;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel6.Location = new System.Drawing.Point(65, 69);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(450, 2);
            this.panel6.TabIndex = 77;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel7.Location = new System.Drawing.Point(65, 335);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(450, 2);
            this.panel7.TabIndex = 78;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel8.Location = new System.Drawing.Point(37, 542);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(900, 2);
            this.panel8.TabIndex = 79;
            // 
            // StartScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1006, 814);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.ShadowPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "StartScreen";
            this.Text = "StartScreen";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ShadowPanel4.ResumeLayout(false);
            this.ShadowPanel4.PerformLayout();
            this.ShadowPanel3.ResumeLayout(false);
            this.ShadowPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.QuickReorderGridView)).EndInit();
            this.ShadowPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox SalespersonBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button ReorderAll;
        private System.Windows.Forms.Button ReorderSingular;
        private System.Windows.Forms.DataGridView QuickReorderGridView;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel ShadowPanel1;
        private System.Windows.Forms.Panel ShadowPanel2;
        private System.Windows.Forms.Panel ShadowPanel3;
        private System.Windows.Forms.Panel ShadowPanel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button AddToNotes;
        private System.Windows.Forms.RichTextBox NoteWriteBox;
        private System.Windows.Forms.Panel NotePanel;
        private System.Windows.Forms.Button demoButton;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
    }
}