﻿namespace finals
{
    partial class CreateNewOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateNewOrder));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ProductIDBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.QuantityBox = new System.Windows.Forms.TextBox();
            this.AddToCartBtn = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.CartGridView = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SalespersonBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ProductCodeHelpBtn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.TotalLabel = new System.Windows.Forms.Label();
            this.CustomerHelpBtn = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.CustomerCodeBox = new System.Windows.Forms.TextBox();
            this.ConfirmCustomerBtn = new System.Windows.Forms.Button();
            this.DividerPanel = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.AccountNumberBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.CreditCardBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.BillingAddressBox = new System.Windows.Forms.TextBox();
            this.SameAddressBox = new System.Windows.Forms.CheckBox();
            this.ShippingAddressBox = new System.Windows.Forms.TextBox();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.TerritoryBox = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.ShippingMethodBox = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.TaxRateLabel = new System.Windows.Forms.Label();
            this.DeliveryFeeLabel = new System.Windows.Forms.Label();
            this.TotalWithFeesLabel = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.CustomerNameBox = new System.Windows.Forms.TextBox();
            this.ConfirmOrderBtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.PostalCodeBox = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.CityBox = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.RemoveFromCart = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.CartGridView)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(344, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 32);
            this.label1.TabIndex = 10;
            this.label1.Text = "Create New Sales Order";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(15, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 25);
            this.label3.TabIndex = 13;
            this.label3.Text = "Product Code:";
            // 
            // ProductIDBox
            // 
            this.ProductIDBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.ProductIDBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ProductIDBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProductIDBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.ProductIDBox.Location = new System.Drawing.Point(0, 0);
            this.ProductIDBox.Name = "ProductIDBox";
            this.ProductIDBox.Size = new System.Drawing.Size(149, 22);
            this.ProductIDBox.TabIndex = 12;
            this.ProductIDBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ProductIDBox_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(257, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 25);
            this.label2.TabIndex = 15;
            this.label2.Text = "Qty:";
            // 
            // QuantityBox
            // 
            this.QuantityBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.QuantityBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.QuantityBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantityBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.QuantityBox.Location = new System.Drawing.Point(0, 0);
            this.QuantityBox.Name = "QuantityBox";
            this.QuantityBox.Size = new System.Drawing.Size(43, 22);
            this.QuantityBox.TabIndex = 14;
            this.QuantityBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.QuantityBox_KeyDown);
            // 
            // AddToCartBtn
            // 
            this.AddToCartBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.AddToCartBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddToCartBtn.FlatAppearance.BorderSize = 0;
            this.AddToCartBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddToCartBtn.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.AddToCartBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.AddToCartBtn.ImageIndex = 0;
            this.AddToCartBtn.ImageList = this.imageList1;
            this.AddToCartBtn.Location = new System.Drawing.Point(0, 0);
            this.AddToCartBtn.Name = "AddToCartBtn";
            this.AddToCartBtn.Size = new System.Drawing.Size(186, 48);
            this.AddToCartBtn.TabIndex = 52;
            this.AddToCartBtn.Text = "Add To Cart";
            this.AddToCartBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.AddToCartBtn.UseVisualStyleBackColor = false;
            this.AddToCartBtn.Click += new System.EventHandler(this.AddToCartBtn_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "ShoppingBasket.png");
            this.imageList1.Images.SetKeyName(1, "CheckMark.png");
            // 
            // CartGridView
            // 
            this.CartGridView.AllowUserToAddRows = false;
            this.CartGridView.AllowUserToDeleteRows = false;
            this.CartGridView.AllowUserToResizeColumns = false;
            this.CartGridView.AllowUserToResizeRows = false;
            this.CartGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.CartGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CartGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.CartGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.CartGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CartGridView.ColumnHeadersVisible = false;
            this.CartGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.CartGridView.DefaultCellStyle = dataGridViewCellStyle10;
            this.CartGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.CartGridView.Location = new System.Drawing.Point(570, 92);
            this.CartGridView.MultiSelect = false;
            this.CartGridView.Name = "CartGridView";
            this.CartGridView.ReadOnly = true;
            this.CartGridView.RowHeadersVisible = false;
            this.CartGridView.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.CartGridView.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.CartGridView.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(78)))), ((int)(((byte)(110)))));
            this.CartGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.CartGridView.ShowCellErrors = false;
            this.CartGridView.Size = new System.Drawing.Size(374, 172);
            this.CartGridView.TabIndex = 53;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Code";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 50;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Name";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 200;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Qty";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 50;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "salespersonid";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 75;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(821, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 20);
            this.label4.TabIndex = 54;
            this.label4.Text = "Qty";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(677, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 20);
            this.label6.TabIndex = 56;
            this.label6.Text = "Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(15, 743);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(148, 25);
            this.label7.TabIndex = 58;
            this.label7.Text = "Salesperson ID:";
            // 
            // SalespersonBox
            // 
            this.SalespersonBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.SalespersonBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SalespersonBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.SalespersonBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.SalespersonBox.Location = new System.Drawing.Point(0, 0);
            this.SalespersonBox.Name = "SalespersonBox";
            this.SalespersonBox.Size = new System.Drawing.Size(72, 22);
            this.SalespersonBox.TabIndex = 59;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(870, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 20);
            this.label8.TabIndex = 60;
            this.label8.Text = "Price";
            // 
            // ProductCodeHelpBtn
            // 
            this.ProductCodeHelpBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ProductCodeHelpBtn.BackgroundImage")));
            this.ProductCodeHelpBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ProductCodeHelpBtn.FlatAppearance.BorderSize = 0;
            this.ProductCodeHelpBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(82)))));
            this.ProductCodeHelpBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ProductCodeHelpBtn.Location = new System.Drawing.Point(181, 117);
            this.ProductCodeHelpBtn.Name = "ProductCodeHelpBtn";
            this.ProductCodeHelpBtn.Size = new System.Drawing.Size(23, 25);
            this.ProductCodeHelpBtn.TabIndex = 61;
            this.ProductCodeHelpBtn.UseVisualStyleBackColor = true;
            this.ProductCodeHelpBtn.Click += new System.EventHandler(this.ProductCodeHelpBtn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(566, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 20);
            this.label5.TabIndex = 55;
            this.label5.Text = "Code";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.label9.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.label9.Location = new System.Drawing.Point(700, 278);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 25);
            this.label9.TabIndex = 62;
            this.label9.Text = "Subtotal: ";
            // 
            // TotalLabel
            // 
            this.TotalLabel.AutoSize = true;
            this.TotalLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.TotalLabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.TotalLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.TotalLabel.Location = new System.Drawing.Point(789, 278);
            this.TotalLabel.Name = "TotalLabel";
            this.TotalLabel.Size = new System.Drawing.Size(34, 25);
            this.TotalLabel.TabIndex = 63;
            this.TotalLabel.Text = "$0";
            // 
            // CustomerHelpBtn
            // 
            this.CustomerHelpBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("CustomerHelpBtn.BackgroundImage")));
            this.CustomerHelpBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.CustomerHelpBtn.FlatAppearance.BorderSize = 0;
            this.CustomerHelpBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(82)))));
            this.CustomerHelpBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CustomerHelpBtn.Location = new System.Drawing.Point(183, 358);
            this.CustomerHelpBtn.Name = "CustomerHelpBtn";
            this.CustomerHelpBtn.Size = new System.Drawing.Size(23, 25);
            this.CustomerHelpBtn.TabIndex = 68;
            this.CustomerHelpBtn.UseVisualStyleBackColor = true;
            this.CustomerHelpBtn.Click += new System.EventHandler(this.CustomerHelpBtn_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(21, 333);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(154, 25);
            this.label11.TabIndex = 67;
            this.label11.Text = "Customer Code:";
            // 
            // CustomerCodeBox
            // 
            this.CustomerCodeBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.CustomerCodeBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CustomerCodeBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerCodeBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.CustomerCodeBox.Location = new System.Drawing.Point(0, 0);
            this.CustomerCodeBox.Name = "CustomerCodeBox";
            this.CustomerCodeBox.Size = new System.Drawing.Size(149, 22);
            this.CustomerCodeBox.TabIndex = 66;
            // 
            // ConfirmCustomerBtn
            // 
            this.ConfirmCustomerBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.ConfirmCustomerBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ConfirmCustomerBtn.FlatAppearance.BorderSize = 0;
            this.ConfirmCustomerBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ConfirmCustomerBtn.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.ConfirmCustomerBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.ConfirmCustomerBtn.Location = new System.Drawing.Point(0, 0);
            this.ConfirmCustomerBtn.Name = "ConfirmCustomerBtn";
            this.ConfirmCustomerBtn.Size = new System.Drawing.Size(116, 38);
            this.ConfirmCustomerBtn.TabIndex = 69;
            this.ConfirmCustomerBtn.Text = "Confirm";
            this.ConfirmCustomerBtn.UseVisualStyleBackColor = false;
            this.ConfirmCustomerBtn.Click += new System.EventHandler(this.ConfirmCustomerBtn_Click);
            // 
            // DividerPanel
            // 
            this.DividerPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(44)))), ((int)(((byte)(63)))));
            this.DividerPanel.Location = new System.Drawing.Point(6, 315);
            this.DividerPanel.Name = "DividerPanel";
            this.DividerPanel.Size = new System.Drawing.Size(982, 2);
            this.DividerPanel.TabIndex = 70;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(548, 333);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(171, 25);
            this.label12.TabIndex = 72;
            this.label12.Text = "Account Number:";
            // 
            // AccountNumberBox
            // 
            this.AccountNumberBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(59)))), ((int)(((byte)(84)))));
            this.AccountNumberBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AccountNumberBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccountNumberBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.AccountNumberBox.Location = new System.Drawing.Point(0, 0);
            this.AccountNumberBox.Name = "AccountNumberBox";
            this.AccountNumberBox.ReadOnly = true;
            this.AccountNumberBox.Size = new System.Drawing.Size(166, 22);
            this.AccountNumberBox.TabIndex = 71;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(780, 333);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(118, 25);
            this.label13.TabIndex = 74;
            this.label13.Text = "Credit Card:";
            // 
            // CreditCardBox
            // 
            this.CreditCardBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(59)))), ((int)(((byte)(84)))));
            this.CreditCardBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CreditCardBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CreditCardBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.CreditCardBox.Location = new System.Drawing.Point(0, 0);
            this.CreditCardBox.Name = "CreditCardBox";
            this.CreditCardBox.ReadOnly = true;
            this.CreditCardBox.Size = new System.Drawing.Size(166, 22);
            this.CreditCardBox.TabIndex = 73;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(308, 411);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(173, 25);
            this.label15.TabIndex = 80;
            this.label15.Text = "Shipping Address:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(659, 411);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(149, 25);
            this.label16.TabIndex = 78;
            this.label16.Text = "Billing Address:";
            // 
            // BillingAddressBox
            // 
            this.BillingAddressBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.BillingAddressBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BillingAddressBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BillingAddressBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.BillingAddressBox.Location = new System.Drawing.Point(0, 0);
            this.BillingAddressBox.Name = "BillingAddressBox";
            this.BillingAddressBox.Size = new System.Drawing.Size(290, 22);
            this.BillingAddressBox.TabIndex = 77;
            // 
            // SameAddressBox
            // 
            this.SameAddressBox.AutoSize = true;
            this.SameAddressBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SameAddressBox.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.SameAddressBox.ForeColor = System.Drawing.Color.White;
            this.SameAddressBox.Location = new System.Drawing.Point(313, 462);
            this.SameAddressBox.Name = "SameAddressBox";
            this.SameAddressBox.Size = new System.Drawing.Size(202, 19);
            this.SameAddressBox.TabIndex = 81;
            this.SameAddressBox.Text = "Billing Address Same As Shipping";
            this.SameAddressBox.UseVisualStyleBackColor = true;
            this.SameAddressBox.CheckedChanged += new System.EventHandler(this.SameAddressBox_CheckedChanged);
            // 
            // ShippingAddressBox
            // 
            this.ShippingAddressBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.ShippingAddressBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ShippingAddressBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShippingAddressBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.ShippingAddressBox.Location = new System.Drawing.Point(0, 0);
            this.ShippingAddressBox.Name = "ShippingAddressBox";
            this.ShippingAddressBox.Size = new System.Drawing.Size(260, 22);
            this.ShippingAddressBox.TabIndex = 82;
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker.Location = new System.Drawing.Point(664, 602);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(234, 25);
            this.dateTimePicker.TabIndex = 83;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(659, 574);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(177, 25);
            this.label17.TabIndex = 84;
            this.label17.Text = "Delivery Due Date:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(21, 574);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(95, 25);
            this.label18.TabIndex = 86;
            this.label18.Text = "Territory:";
            // 
            // TerritoryBox
            // 
            this.TerritoryBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.TerritoryBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TerritoryBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TerritoryBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.TerritoryBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.TerritoryBox.FormattingEnabled = true;
            this.TerritoryBox.Items.AddRange(new object[] {
            "Northwest US, North America",
            "Northeast US, North America",
            "Central US, North America",
            "Southwest US, North America",
            "Southeast US, North America",
            "Canada CA, North America",
            "France FR, Europe",
            "Germany DE, Europe",
            "Australia AU, Pacific",
            "United Kingdom GB, Europe"});
            this.TerritoryBox.Location = new System.Drawing.Point(26, 602);
            this.TerritoryBox.Name = "TerritoryBox";
            this.TerritoryBox.Size = new System.Drawing.Size(226, 25);
            this.TerritoryBox.TabIndex = 85;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(308, 574);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(172, 25);
            this.label19.TabIndex = 88;
            this.label19.Text = "Shipping Method:";
            // 
            // ShippingMethodBox
            // 
            this.ShippingMethodBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(43)))), ((int)(((byte)(61)))));
            this.ShippingMethodBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShippingMethodBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ShippingMethodBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.ShippingMethodBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.ShippingMethodBox.FormattingEnabled = true;
            this.ShippingMethodBox.Items.AddRange(new object[] {
            "XRQ - TRUCK GROUND - $3.95",
            "ZY - EXPRESS - $9.95",
            "OVERSEAS - DELUXE - $29.95",
            "OVERNIGHT J-FAST - $21.95",
            "CARGO TRANSPORT 5 - $8.99"});
            this.ShippingMethodBox.Location = new System.Drawing.Point(313, 602);
            this.ShippingMethodBox.Name = "ShippingMethodBox";
            this.ShippingMethodBox.Size = new System.Drawing.Size(226, 25);
            this.ShippingMethodBox.TabIndex = 87;
            this.ShippingMethodBox.SelectedIndexChanged += new System.EventHandler(this.ShippingMethodBox_SelectedIndexChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.label20.Location = new System.Drawing.Point(21, 630);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(91, 25);
            this.label20.TabIndex = 89;
            this.label20.Text = "Tax Rate:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.label21.Location = new System.Drawing.Point(308, 630);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(125, 25);
            this.label21.TabIndex = 90;
            this.label21.Text = "Delivery Fee:";
            // 
            // TaxRateLabel
            // 
            this.TaxRateLabel.AutoSize = true;
            this.TaxRateLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.TaxRateLabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.TaxRateLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.TaxRateLabel.Location = new System.Drawing.Point(116, 630);
            this.TaxRateLabel.Name = "TaxRateLabel";
            this.TaxRateLabel.Size = new System.Drawing.Size(39, 25);
            this.TaxRateLabel.TabIndex = 91;
            this.TaxRateLabel.Text = "%0";
            // 
            // DeliveryFeeLabel
            // 
            this.DeliveryFeeLabel.AutoSize = true;
            this.DeliveryFeeLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.DeliveryFeeLabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.DeliveryFeeLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.DeliveryFeeLabel.Location = new System.Drawing.Point(439, 630);
            this.DeliveryFeeLabel.Name = "DeliveryFeeLabel";
            this.DeliveryFeeLabel.Size = new System.Drawing.Size(34, 25);
            this.DeliveryFeeLabel.TabIndex = 92;
            this.DeliveryFeeLabel.Text = "$0";
            // 
            // TotalWithFeesLabel
            // 
            this.TotalWithFeesLabel.AutoSize = true;
            this.TotalWithFeesLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.TotalWithFeesLabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.TotalWithFeesLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.TotalWithFeesLabel.Location = new System.Drawing.Point(78, 696);
            this.TotalWithFeesLabel.Name = "TotalWithFeesLabel";
            this.TotalWithFeesLabel.Size = new System.Drawing.Size(34, 25);
            this.TotalWithFeesLabel.TabIndex = 94;
            this.TotalWithFeesLabel.Text = "$0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.label23.Location = new System.Drawing.Point(21, 696);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 25);
            this.label23.TabIndex = 93;
            this.label23.Text = "Total:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(308, 333);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(69, 25);
            this.label14.TabIndex = 96;
            this.label14.Text = "Name:";
            // 
            // CustomerNameBox
            // 
            this.CustomerNameBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(59)))), ((int)(((byte)(84)))));
            this.CustomerNameBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CustomerNameBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerNameBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.CustomerNameBox.Location = new System.Drawing.Point(0, 0);
            this.CustomerNameBox.Name = "CustomerNameBox";
            this.CustomerNameBox.ReadOnly = true;
            this.CustomerNameBox.Size = new System.Drawing.Size(166, 22);
            this.CustomerNameBox.TabIndex = 95;
            // 
            // ConfirmOrderBtn
            // 
            this.ConfirmOrderBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(61)))), ((int)(((byte)(87)))));
            this.ConfirmOrderBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ConfirmOrderBtn.FlatAppearance.BorderSize = 0;
            this.ConfirmOrderBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ConfirmOrderBtn.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.ConfirmOrderBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(156)))), ((int)(((byte)(255)))));
            this.ConfirmOrderBtn.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.ConfirmOrderBtn.ImageIndex = 1;
            this.ConfirmOrderBtn.ImageList = this.imageList1;
            this.ConfirmOrderBtn.Location = new System.Drawing.Point(0, 0);
            this.ConfirmOrderBtn.Name = "ConfirmOrderBtn";
            this.ConfirmOrderBtn.Size = new System.Drawing.Size(187, 56);
            this.ConfirmOrderBtn.TabIndex = 97;
            this.ConfirmOrderBtn.Text = "Confirm Order";
            this.ConfirmOrderBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ConfirmOrderBtn.UseVisualStyleBackColor = false;
            this.ConfirmOrderBtn.Click += new System.EventHandler(this.ConfirmOrderBtn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(44)))), ((int)(((byte)(63)))));
            this.panel1.Location = new System.Drawing.Point(6, 724);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(982, 2);
            this.panel1.TabIndex = 71;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(308, 498);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 25);
            this.label10.TabIndex = 99;
            this.label10.Text = "Postal Code:";
            // 
            // PostalCodeBox
            // 
            this.PostalCodeBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(59)))), ((int)(((byte)(84)))));
            this.PostalCodeBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.PostalCodeBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PostalCodeBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.PostalCodeBox.Location = new System.Drawing.Point(0, 0);
            this.PostalCodeBox.Name = "PostalCodeBox";
            this.PostalCodeBox.ReadOnly = true;
            this.PostalCodeBox.Size = new System.Drawing.Size(140, 22);
            this.PostalCodeBox.TabIndex = 98;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(659, 498);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(51, 25);
            this.label22.TabIndex = 101;
            this.label22.Text = "City:";
            // 
            // CityBox
            // 
            this.CityBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(59)))), ((int)(((byte)(84)))));
            this.CityBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CityBox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CityBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.CityBox.Location = new System.Drawing.Point(0, 0);
            this.CityBox.Name = "CityBox";
            this.CityBox.ReadOnly = true;
            this.CityBox.Size = new System.Drawing.Size(191, 22);
            this.CityBox.TabIndex = 100;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(44)))), ((int)(((byte)(63)))));
            this.panel2.Location = new System.Drawing.Point(6, 44);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(982, 2);
            this.panel2.TabIndex = 71;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel3.Controls.Add(this.ProductIDBox);
            this.panel3.Location = new System.Drawing.Point(20, 120);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(151, 24);
            this.panel3.TabIndex = 102;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel4.Controls.Add(this.QuantityBox);
            this.panel4.Location = new System.Drawing.Point(262, 120);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(45, 24);
            this.panel4.TabIndex = 103;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel5.Controls.Add(this.AddToCartBtn);
            this.panel5.Location = new System.Drawing.Point(350, 105);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(189, 51);
            this.panel5.TabIndex = 104;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel6.Controls.Add(this.SalespersonBox);
            this.panel6.Location = new System.Drawing.Point(20, 775);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(74, 24);
            this.panel6.TabIndex = 104;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel7.Controls.Add(this.CustomerCodeBox);
            this.panel7.Location = new System.Drawing.Point(26, 361);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(151, 24);
            this.panel7.TabIndex = 105;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel8.Controls.Add(this.ConfirmCustomerBtn);
            this.panel8.Location = new System.Drawing.Point(36, 411);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(119, 41);
            this.panel8.TabIndex = 106;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel9.Controls.Add(this.ShippingAddressBox);
            this.panel9.Location = new System.Drawing.Point(313, 437);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(262, 24);
            this.panel9.TabIndex = 107;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel10.Controls.Add(this.BillingAddressBox);
            this.panel10.Location = new System.Drawing.Point(664, 439);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(292, 24);
            this.panel10.TabIndex = 108;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel11.Controls.Add(this.ConfirmOrderBtn);
            this.panel11.Location = new System.Drawing.Point(403, 743);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(190, 59);
            this.panel11.TabIndex = 109;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel12.Controls.Add(this.CustomerNameBox);
            this.panel12.Location = new System.Drawing.Point(313, 358);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(168, 24);
            this.panel12.TabIndex = 110;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel13.Controls.Add(this.AccountNumberBox);
            this.panel13.Location = new System.Drawing.Point(553, 361);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(168, 24);
            this.panel13.TabIndex = 111;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel14.Controls.Add(this.CreditCardBox);
            this.panel14.Location = new System.Drawing.Point(785, 358);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(168, 24);
            this.panel14.TabIndex = 112;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel15.Controls.Add(this.PostalCodeBox);
            this.panel15.Location = new System.Drawing.Point(313, 526);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(142, 24);
            this.panel15.TabIndex = 113;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(49)))));
            this.panel16.Controls.Add(this.CityBox);
            this.panel16.Location = new System.Drawing.Point(664, 526);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(193, 24);
            this.panel16.TabIndex = 114;
            // 
            // RemoveFromCart
            // 
            this.RemoveFromCart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("RemoveFromCart.BackgroundImage")));
            this.RemoveFromCart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.RemoveFromCart.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.RemoveFromCart.FlatAppearance.BorderSize = 0;
            this.RemoveFromCart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RemoveFromCart.Location = new System.Drawing.Point(950, 95);
            this.RemoveFromCart.Name = "RemoveFromCart";
            this.RemoveFromCart.Size = new System.Drawing.Size(37, 25);
            this.RemoveFromCart.TabIndex = 115;
            this.RemoveFromCart.UseVisualStyleBackColor = true;
            this.RemoveFromCart.Click += new System.EventHandler(this.RemoveFromCart_Click);
            // 
            // CreateNewOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1006, 814);
            this.Controls.Add(this.RemoveFromCart);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.TotalWithFeesLabel);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.DeliveryFeeLabel);
            this.Controls.Add(this.TaxRateLabel);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.ShippingMethodBox);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.TerritoryBox);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.SameAddressBox);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.DividerPanel);
            this.Controls.Add(this.CustomerHelpBtn);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.TotalLabel);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.ProductCodeHelpBtn);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.CartGridView);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CreateNewOrder";
            this.Text = "Create New Sales Order";
            ((System.ComponentModel.ISupportInitialize)(this.CartGridView)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ProductIDBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox QuantityBox;
        private System.Windows.Forms.Button AddToCartBtn;
        private System.Windows.Forms.DataGridView CartGridView;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox SalespersonBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button ProductCodeHelpBtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label TotalLabel;
        private System.Windows.Forms.Button CustomerHelpBtn;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox CustomerCodeBox;
        private System.Windows.Forms.Button ConfirmCustomerBtn;
        private System.Windows.Forms.Panel DividerPanel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox AccountNumberBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox CreditCardBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox BillingAddressBox;
        private System.Windows.Forms.CheckBox SameAddressBox;
        private System.Windows.Forms.TextBox ShippingAddressBox;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox TerritoryBox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox ShippingMethodBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label TaxRateLabel;
        private System.Windows.Forms.Label DeliveryFeeLabel;
        private System.Windows.Forms.Label TotalWithFeesLabel;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox CustomerNameBox;
        private System.Windows.Forms.Button ConfirmOrderBtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox PostalCodeBox;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox CityBox;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Button RemoveFromCart;
    }
}