﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finals
{
    class CartItem
    {
        public int code, qty;
        public double singlePrice;

        public CartItem(int code, int qty, double singlePrice)
        {
            this.code = code;
            this.qty = qty;
            this.singlePrice = singlePrice;
        }

        public override string ToString()
        {
            return $"ID: {this.code}, Qty: {this.qty}, Single Price: {this.singlePrice}";
        }
    }
}
