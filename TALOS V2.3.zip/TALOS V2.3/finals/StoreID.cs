﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finals
{
    public partial class StoreID : Form
    {
        TextBox StoreIDBox;
        public StoreID(TextBox tb)
        {
            InitializeComponent();

            string sql = "select BusinessEntityID as ID,name as Name from sales.store order by BusinessEntityID asc";
            string connectionString = Functions.GetConnectionString();
            SqlConnection con;
            SqlCommand command;
            SqlDataAdapter da;

            con = new SqlConnection(connectionString);
            con.Open();
            command = new SqlCommand(sql, con);
            da = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);
            StoreGridView.DataSource = dt;

            StoreGridView.Font = new Font("Segoe UI Semibold", 12, FontStyle.Bold);
            StoreGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            StoreGridView.Columns[0].Width = 60;
            StoreGridView.Columns[1].Width = 250;

            StoreIDBox = tb;
        }

        public void SearchName()
        {
            (StoreGridView.DataSource as DataTable).DefaultView.RowFilter = string.Format("Name LIKE '%{0}%'", SearchBox.Text);
        }

        public void SearchCode()
        {
            BindingSource bs_sp = new BindingSource();

            bs_sp.DataSource = StoreGridView.DataSource;
            bs_sp.Filter = "Convert(ID, 'System.String') like '" + SearchBoxCode.Text + "%'";
            StoreGridView.DataSource = bs_sp;
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            SearchName();
            SearchBoxCode.Text = "";
        }

        private void SearchBoxCode_KeyDown(object sender, KeyEventArgs e)
        {
            SearchBox.Text = "";
            SearchCode();
        }

        private void StoreGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                StoreIDBox.Text = StoreGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                this.Dispose();
            }
            catch
            {

            }
        }
    }
}
